//using System;
//using System.Runtime.Caching;
//using System.Web;
//using System.Web.Mvc;

//public class RateLimitAttribute : ActionFilterAttribute
//{
//    public int MaxRequests { get; set; }
//    public int Seconds { get; set; }

//    private static readonly ObjectCache cache = MemoryCache.Default;

//    public override void OnActionExecuting(ActionExecutingContext filterContext)
//    {
//        var request = filterContext.HttpContext.Request;
//        var ip = request.UserHostAddress;

//        string key = $"rate_limit_{ip}";
//        int count = (int?)cache[key] ?? 0;

//        if (count >= MaxRequests)
//        {
//            filterContext.Result = new ContentResult
//            {
//                Content = "Too many login attempts. Try again later."
//            };
//            return;
//        }

//        cache.Set(key, count + 1, DateTimeOffset.Now.AddSeconds(Seconds));
//    }
//}