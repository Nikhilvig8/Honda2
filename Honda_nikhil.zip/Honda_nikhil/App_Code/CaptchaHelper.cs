using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Web;

public class CaptchaHelper
{
    private static Random random = new Random();

    public static string GenerateRandomCode(int length = 6)
    {
        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        char[] code = new char[length];

        for (int i = 0; i < length; i++)
        {
            code[i] = chars[random.Next(chars.Length)];
        }

        return new string(code);
    }

    public static byte[] GenerateCaptchaImage(string captchaText)
    {
        int width = 150;
        int height = 50;

        using (Bitmap bitmap = new Bitmap(width, height))
        using (Graphics g = Graphics.FromImage(bitmap))
        {
            g.Clear(Color.White);

            Font font = new Font("Arial", 20, FontStyle.Bold);
            Brush brush = new SolidBrush(Color.Black);

            g.DrawString(captchaText, font, brush, 10, 10);

            // Add noise
            for (int i = 0; i < 50; i++)
            {
                int x = random.Next(width);
                int y = random.Next(height);
                bitmap.SetPixel(x, y, Color.Gray);
            }

            using (MemoryStream ms = new MemoryStream())
            {
                bitmap.Save(ms, ImageFormat.Png);
                return ms.ToArray();
            }
        }
    }
}

//using System;
//using System.Drawing;
//using System.Drawing.Imaging;
//using System.IO;

//public class CaptchaHelper
//{
//    private static Random random = new Random();

//    public static string GenerateRandomCode(int length = 6)
//    {
//        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
//        char[] code = new char[length];

//        for (int i = 0; i < length; i++)
//        {
//            code[i] = chars[random.Next(chars.Length)];
//        }

//        return new string(code);
//    }

//    public static byte[] GenerateCaptchaImage(string captchaText)
//    {
//        int width = 150;
//        int height = 50;

//        using (Bitmap bitmap = new Bitmap(width, height))
//        using (Graphics g = Graphics.FromImage(bitmap))
//        {
//            // Set a random background color
//            g.Clear(GetRandomColor());

//            // Random font style and color for more complexity
//            Font[] fonts = new Font[]
//            {
//                new Font("Arial", 20, FontStyle.Bold),
//                new Font("Verdana", 18, FontStyle.Italic),
//                new Font("Comic Sans MS", 22, FontStyle.Regular)
//            };

//            Brush[] brushes = new Brush[]
//            {
//                new SolidBrush(GetRandomColor()),
//                new SolidBrush(GetRandomColor()),
//                new SolidBrush(GetRandomColor())
//            };

//            // Draw the CAPTCHA text with some random distortion
//            for (int i = 0; i < captchaText.Length; i++)
//            {
//                Font randomFont = fonts[random.Next(fonts.Length)];
//                Brush randomBrush = brushes[random.Next(brushes.Length)];

//                // Distort the text by slightly rotating it
//                float angle = (float)(random.NextDouble() * 30 - 15); // Rotation between -15 to 15 degrees
//                g.RotateTransform(angle);

//                // Draw each character at random positions
//                g.DrawString(captchaText[i].ToString(), randomFont, randomBrush, 20 + (i * 25), 10);

//                // Reset rotation after drawing each character
//                g.RotateTransform(-angle);
//            }

//            // Add noise (lines, dots, and random shapes)
//            AddNoise(g, width, height);

//            using (MemoryStream ms = new MemoryStream())
//            {
//                bitmap.Save(ms, ImageFormat.Png);
//                return ms.ToArray();
//            }
//        }
//    }

//    // Add some noise to the background (random lines and dots)
//    private static void AddNoise(Graphics g, int width, int height)
//    {
//        for (int i = 0; i < 30; i++)
//        {
//            int x1 = random.Next(width);
//            int y1 = random.Next(height);
//            int x2 = random.Next(width);
//            int y2 = random.Next(height);
//            g.DrawLine(new Pen(Color.Gray), x1, y1, x2, y2);
//        }

//        for (int i = 0; i < 50; i++)
//        {
//            int x = random.Next(width);
//            int y = random.Next(height);
//            g.FillEllipse(new SolidBrush(Color.Gray), x, y, 2, 2);
//        }
//    }

//    // Get a random color for the CAPTCHA
//    private static Color GetRandomColor()
//    {
//        return Color.FromArgb(random.Next(256), random.Next(256), random.Next(256));
//    }
//}