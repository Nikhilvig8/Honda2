﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using DataUtilityLayer;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using Honda;
using System.Net.Mail;
using QlikAuthNet;
using System.Web.Security;
using Honda.Models;
using System.Net;
using System.Text;
using System.Security.Cryptography.X509Certificates;
using MySql.Data.MySqlClient;
using System.Web.UI;

namespace Honda.Controllers
{
    [HandleError()]
    public class HomeController : Controller
    {
        string method = ConfigurationManager.ConnectionStrings["method"].ToString();
        string host = ConfigurationManager.ConnectionStrings["host"].ToString();
        string host_Typ = ConfigurationManager.ConnectionStrings["hostType"].ToString();
        // string username = ConfigurationManager.ConnectionStrings["username"].ToString();
        string userdirectory = ConfigurationManager.ConnectionStrings["userdirectory"].ToString();
        string port = ConfigurationManager.ConnectionStrings["port"].ToString();
        string port_tkt = ConfigurationManager.ConnectionStrings["port_tkt"].ToString();
        string tkthost = ConfigurationManager.ConnectionStrings["tkthost"].ToString();

        public string conn = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
        MySqlCommand cmdObj;
        PassEncrypt pe = new PassEncrypt();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult first_login_Password()
        {
            return View();
        }
        public ActionResult first_login_Password_Update(string pass)
        {
            Session["Popup"] = null;
            var status = Update_pass_Firsttime(pass);
            // Session["Url"] = "http://iamsrinu.com/bluemoon2.1/";
            Session["Optype"] = "dash";

            string ticket = null;
            //For Dashboard 
            //if (Session["QlikTicket"] == null)
            //{
            ticket = Get_Ticket();

            Session["QlikTicket"] = ticket;
            //}
            //else
            //{
            //    ticket = Session["QlikTicket"].ToString();
            //}
            string Url = host_Typ + "://" + host + port + "/header/hub?qlikticket=" + ticket;

            // For Demo
            // string Url = "https://demos.qlik.com/qliksense";
            Session["Url"] = Url;
            // return RedirectToAction("iframeIndex", "Home");
            return Json(status, JsonRequestBehavior.AllowGet);

        }
        public ActionResult iframeIndex(string mapping)
        {
            return View();
        }
        public ActionResult iframeIndexRedirect(string par)
        {
            Session["Optype"] = par;
            if (par == "dash")
            {
                //Session["Url"] = "http://iamsrinu.com/bluemoon2.1/";



                string ticket = null;
                //For Dashboard 
                //if (Session["QlikTicket"] == null)
                //{
                ticket = Get_Ticket();
                Session["QlikTicket"] = ticket;
                //}
                //else
                //{
                //    ticket = Session["QlikTicket"].ToString();
                //}
                string Url = host_Typ + "://" + host + port + "/header/hub?qlikticket=" + ticket;

                // For Demo
                // string Url = "https://demos.qlik.com/qliksense";
                Session["Url"] = Url;


                return RedirectToAction("iframeIndex", "Home", new { Mapping = Session["Mapping"].ToString() });
            }
            else
            {
                //UrlHelper u = new UrlHelper(this.ControllerContext.RequestContext);
                //string url = u.Action("About", "Home", null);
                if (Session["Type"].ToString() == "admin")
                {
                    Session["Url"] = Url.Action("Index", "Home");
                }
                else { Session["Url"] = Url.Action("IndexUser", "Home"); }
                return RedirectToAction("iframeIndex", "Home", new { Mapping = Session["Mapping"].ToString() });
            }

        }
        public ActionResult IndexUser()
        {
            return View();
        }
        public ActionResult UpdateProfile()
        {

            return View();
        }
        public ActionResult UpdateProfile_Submit(string Firstname, string Lastname, string Email, string Role, string Organization, string Operation, string Department, string Location_Code, string Zone, string Region, string Area, string Contact, string Mapping)
        {

            var status = Update_User(Firstname, Lastname, Email, Role, Organization, Operation, Department, Location_Code, Zone, Region, Area, Contact, Mapping);
            return Json(status, JsonRequestBehavior.AllowGet);
        }
        public ActionResult ChangePassword()
        {

            return View();
        }
        public ActionResult ChangePassword_User()
        {

            return View();
        }
        public ActionResult ChangePassword_Update(string old_pass, string new_pass)
        {

            var status = Update_pass(old_pass, new_pass);
            return Json(status, JsonRequestBehavior.AllowGet);
        }
        public ActionResult Old_Pass_details(string Uid)
        {
            var status = GetOldPass(Uid);
            return Json(status, JsonRequestBehavior.AllowGet);
        }
        public ActionResult ChangePasswordUser_Update(string Uid, string new_pass)
        {

            var status = Update_passUser(Uid, new_pass);
            return Json(status, JsonRequestBehavior.AllowGet);
        }
 public ActionResult Delete_User(string User)
        {

            var status = DeleteUser(User);
            return Json(status, JsonRequestBehavior.AllowGet);
        }
 public ActionResult Updatetable_User(string firstname, string lastname, string username, string Role, string Organization, string Operation, string Department, string Status, string Location_Code, string Zone, string Region, string Area, string Mapping)
        {

            var status = UpdateTableData(firstname, lastname, username, Role, Organization, Operation, Department, Status, Location_Code, Zone, Region, Area, Mapping);
            return Json(status, JsonRequestBehavior.AllowGet);
        }
   public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }
        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
  public ActionResult NewUser(string Firstname, string Lastname, string UserName, string Password, string Email, string Role, string Organization, string Operation, string Department, string Contact, string Location_Code, string Zone, string Region, string Area, string Mapping)
        {

            var status = Insert_NewUser(Firstname, Lastname, UserName, Password, Email, Role, Organization, Operation, Department, Contact, Location_Code, Zone, Region, Area, Mapping);
            return Json(status, JsonRequestBehavior.AllowGet);
        }
        public ActionResult User_Lock(string username)
        {

            var status = lockUser(username);
            return Json(status, JsonRequestBehavior.AllowGet);
        }
        public string Insert_NewUser(string Firstname, string Lastname, string UserName, string Password, string Email, string Role, string Organization, string Operation, string Department, string contact, string Location_Code, string Zone, string Region, string Area, string Mapping)
        {
            DataUtility du = new DataUtility();
            MySqlParameter result = new MySqlParameter("@result", MySqlDbType.VarChar, 100) { Direction = ParameterDirection.Output };

            cmdObj = new MySqlCommand();
            cmdObj.CommandText = "Insert_NewUser";

            cmdObj.Parameters
                .Add(new MySqlParameter("@firstname", MySqlDbType.LongText))
                .Value = Firstname.Trim();
            cmdObj.Parameters
                .Add(new MySqlParameter("@lastname", MySqlDbType.LongText))
                .Value = Lastname.Trim();
            cmdObj.Parameters
                  .Add(new MySqlParameter("@UserName", MySqlDbType.LongText))
                  .Value = UserName.Trim();
            cmdObj.Parameters
                  .Add(new MySqlParameter("@Password", MySqlDbType.LongText))
                  .Value = pe.Encrypt(Password.Trim());
            cmdObj.Parameters
                  .Add(new MySqlParameter("@email", MySqlDbType.LongText))
                  .Value = Email.Trim();

            cmdObj.Parameters
                 .Add(new MySqlParameter("@Role", MySqlDbType.LongText))
                 .Value = Role.Trim();
            cmdObj.Parameters
                 .Add(new MySqlParameter("@Organization", MySqlDbType.LongText))
                 .Value = Organization.Trim();

            cmdObj.Parameters
                 .Add(new MySqlParameter("@Operation", MySqlDbType.LongText))
                 .Value = Operation.Trim();
            cmdObj.Parameters
                  .Add(new MySqlParameter("@Department", MySqlDbType.LongText))
                  .Value = Department.Trim();
            cmdObj.Parameters
               .Add(new MySqlParameter("@Location_Code", MySqlDbType.LongText))
               .Value = Location_Code.Trim();
            cmdObj.Parameters
               .Add(new MySqlParameter("@Zone", MySqlDbType.LongText))
               .Value = Zone.Trim();
            cmdObj.Parameters
               .Add(new MySqlParameter("@Region", MySqlDbType.LongText))
               .Value = Region.Trim();
            cmdObj.Parameters
               .Add(new MySqlParameter("@Area", MySqlDbType.LongText))
               .Value = Area.Trim();
            cmdObj.Parameters
                .Add(new MySqlParameter("@Contact", MySqlDbType.LongText))
                .Value = contact.Trim();
            cmdObj.Parameters
                .Add(new MySqlParameter("@Mapping", MySqlDbType.LongText))
                .Value = Mapping.Trim();
            cmdObj.Parameters.Add(result);
            if (du.ExecuteSqlProcedure(cmdObj))
            {

                return result.Value.ToString();
            }
            else { return "Somthing went wrong."; }

        }
        public bool Update_User(string Firstname, string Lastname, string Email, string Role, string Organization, string Operation, string Department, string Location_Code, string Zone, string Region, string Area, string Contact, string Mapping)
        {
            DataUtility du = new DataUtility();
            cmdObj = new MySqlCommand();
            cmdObj.CommandText = "Update_User";

            cmdObj.Parameters
                .Add(new MySqlParameter("@firstname", MySqlDbType.LongText))
                .Value = Firstname.Trim();
            cmdObj.Parameters
                .Add(new MySqlParameter("@lastname", MySqlDbType.LongText))
                .Value = Lastname.Trim();
            cmdObj.Parameters
                  .Add(new MySqlParameter("@UserName", MySqlDbType.LongText))
                  .Value = Session["Uid"].ToString().Trim();
            cmdObj.Parameters
                  .Add(new MySqlParameter("@email", MySqlDbType.LongText))
                  .Value = Email.Trim();

            cmdObj.Parameters
                 .Add(new MySqlParameter("@Role", MySqlDbType.LongText))
                 .Value = Role.Trim();
            cmdObj.Parameters
                 .Add(new MySqlParameter("@Organization", MySqlDbType.LongText))
                 .Value = Organization.Trim();

            cmdObj.Parameters
                 .Add(new MySqlParameter("@Operation", MySqlDbType.LongText))
                 .Value = Operation.Trim();
            cmdObj.Parameters
                  .Add(new MySqlParameter("@Department", MySqlDbType.LongText))
                  .Value = Department.Trim();
            cmdObj.Parameters
                 .Add(new MySqlParameter("@Location_Code", MySqlDbType.LongText))
                 .Value = Location_Code.Trim();
            cmdObj.Parameters
                .Add(new MySqlParameter("@Zone", MySqlDbType.LongText))
                .Value = Zone.Trim();
            cmdObj.Parameters
                .Add(new MySqlParameter("@Region", MySqlDbType.LongText))
                .Value = Region.Trim();
            cmdObj.Parameters
                .Add(new MySqlParameter("@Area", MySqlDbType.LongText))
                .Value = Area.Trim();
            cmdObj.Parameters
                .Add(new MySqlParameter("@Contact", MySqlDbType.LongText))
                .Value = Contact.Trim();
            cmdObj.Parameters
               .Add(new MySqlParameter("@Mapping", MySqlDbType.LongText))
               .Value = Mapping.Trim();
            if (du.ExecuteSqlProcedure(cmdObj))
            {
                Session["UserName"] = Firstname + " " + Lastname;
                return true;
            }
            else { return false; }

        }
        public bool UpdateTableData(string firstname, string lastname, string username, string Role, string Organization, string Operation, string Department, string Status, string Location_Code, string Zone, string Region, string Area, string Mapping)
        {

            DataUtility du = new DataUtility();
            cmdObj = new MySqlCommand();
            cmdObj.CommandText = "UpdateTableData";

            cmdObj.Parameters
                .Add(new MySqlParameter("@firstname", MySqlDbType.LongText))
                .Value = firstname.Trim();
            cmdObj.Parameters
                .Add(new MySqlParameter("@lastname", MySqlDbType.LongText))
                .Value = lastname.Trim();
            cmdObj.Parameters
                  .Add(new MySqlParameter("@UserName", MySqlDbType.LongText))
                  .Value = username.Trim();

            cmdObj.Parameters
                 .Add(new MySqlParameter("@Role", MySqlDbType.LongText))
                 .Value = Role.Trim();
            cmdObj.Parameters
                 .Add(new MySqlParameter("@Organization", MySqlDbType.LongText))
                 .Value = Organization.Trim();

            cmdObj.Parameters
                 .Add(new MySqlParameter("@Operation", MySqlDbType.LongText))
                 .Value = Operation.Trim();
            cmdObj.Parameters
                  .Add(new MySqlParameter("@Department", MySqlDbType.LongText))
                  .Value = Department.Trim();
            cmdObj.Parameters
                 .Add(new MySqlParameter("@Location_Code", MySqlDbType.LongText))
                 .Value = Location_Code.Trim();
            cmdObj.Parameters
               .Add(new MySqlParameter("@Zone", MySqlDbType.LongText))
               .Value = Zone.Trim();
            cmdObj.Parameters
               .Add(new MySqlParameter("@Region", MySqlDbType.LongText))
               .Value = Region.Trim();
            cmdObj.Parameters
               .Add(new MySqlParameter("@Area", MySqlDbType.LongText))
               .Value = Area.Trim();
            cmdObj.Parameters
                  .Add(new MySqlParameter("@Status", MySqlDbType.LongText))
                  .Value = Status.Trim();
            cmdObj.Parameters
               .Add(new MySqlParameter("@Mapping", MySqlDbType.LongText))
               .Value = Mapping.Trim();
            if (du.ExecuteSqlProcedure(cmdObj))
            {

                return true;
            }
            else { return false; }

        }
        public string Update_pass(string old_pass, string new_pass)
        {

            DataUtility du = new DataUtility();
            MySqlParameter result = new MySqlParameter("@result", MySqlDbType.VarChar, 100) { Direction = ParameterDirection.Output };

            cmdObj = new MySqlCommand();
            cmdObj.CommandText = "Update_Password";

            cmdObj.Parameters
                .Add(new MySqlParameter("@old_pass", MySqlDbType.LongText))
                .Value = pe.Encrypt(old_pass.Trim());
            cmdObj.Parameters
                .Add(new MySqlParameter("@pass", MySqlDbType.LongText))
                .Value = pe.Encrypt(new_pass.Trim());
            cmdObj.Parameters
                  .Add(new MySqlParameter("@Uid", MySqlDbType.LongText))
                  .Value = Session["Uid"].ToString().Trim();
            cmdObj.Parameters.Add(result);
            if (du.ExecuteSqlProcedure(cmdObj))
            { return result.Value.ToString(); }
            else { return "Somthing went wrong."; }

        }
        public string Update_passUser(string Uid, string new_pass)
        {

            DataUtility du = new DataUtility();
            MySqlParameter result = new MySqlParameter("@result", MySqlDbType.LongText, 100) { Direction = ParameterDirection.Output };

            cmdObj = new MySqlCommand();
            cmdObj.CommandText = "Update_PasswordUser";


            cmdObj.Parameters
                .Add(new MySqlParameter("@pass", MySqlDbType.LongText))
                .Value = pe.Encrypt(new_pass.Trim());
            cmdObj.Parameters
                  .Add(new MySqlParameter("@Uid", MySqlDbType.LongText))
                  .Value = Uid.Trim();
            cmdObj.Parameters.Add(result);
            if (du.ExecuteSqlProcedure(cmdObj))
            { return result.Value.ToString(); }
            else { return "Somthing went wrong."; }

        }
        public string Update_pass_Firsttime(string new_pass)
        {

            DataUtility du = new DataUtility();
            MySqlParameter result = new MySqlParameter("@result", MySqlDbType.VarChar, 100) { Direction = ParameterDirection.Output };

            cmdObj = new MySqlCommand();
            cmdObj.CommandText = "Update_Password_firsttime";

            cmdObj.Parameters
                 .Add(new MySqlParameter("@pass", MySqlDbType.LongText))
                 .Value = pe.Encrypt(new_pass.Trim());
            cmdObj.Parameters
                  .Add(new MySqlParameter("@Uid", MySqlDbType.LongText))
                  .Value = Session["Uid"].ToString().Trim();
            cmdObj.Parameters.Add(result);
            if (du.ExecuteSqlProcedure(cmdObj))
            { return result.Value.ToString(); }
            else { return "Somthing went wrong."; }

        }
        public string GetOldPass(string Uid)
        {
            DataUtility d = new DataUtility();

            string Opass = string.Empty;
            try
            {
                MySqlConnection co = new MySqlConnection(conn);

                cmdObj = new MySqlCommand("getOldPass", co);
                //cmdObj.CommandText = "getOldPass";

                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters
                     .Add(new MySqlParameter("@Uid", MySqlDbType.LongText))
                     .Value = Uid.Trim();
                co.Open();
                var rdr = cmdObj.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        Opass = pe.Decrypt(rdr["Password"].ToString());
                    }
                }
                else
                {
                    Opass = string.Empty;

                }
                co.Close();
                co.Dispose();
            }
            catch (Exception ex)
            { writeLog(ex.Message); }
            return Opass;
        }
        public string DeleteUser(string User)
        {

            DataUtility du = new DataUtility();
            // MySqlParameter result = new MySqlParameter("@result", MySqlDbType.VarChar, 100) { Direction = ParameterDirection.Output };

            cmdObj = new MySqlCommand();
            cmdObj.CommandText = "Delete_User";

            cmdObj.Parameters
         .Add(new MySqlParameter("@Uid", MySqlDbType.LongText))
         .Value = User.Trim();
            //cmdObj.Parameters.Add(result);
            if (du.ExecuteSqlProcedure(cmdObj))
            { return "true"; }
            else { return "Somthing went wrong."; }





        }
        public string lockUser(string User)
        {

            DataUtility du = new DataUtility();
            //MySqlParameter result = new MySqlParameter("@result", MySqlDbType.VarChar, 100) { Direction = ParameterDirection.Output };

            cmdObj = new MySqlCommand();
            cmdObj.CommandText = "getUserlock";

            cmdObj.Parameters
         .Add(new MySqlParameter("@Uid", MySqlDbType.LongText))
         .Value = User.Trim();

            if (du.ExecuteSqlProcedure(cmdObj))
            { return "User has been locked please reset the password."; }
            else { return "Somthing went wrong."; }





        }
        public ActionResult GetEditableData(String user)
        {
            DataUtility du = new DataUtility();
            string opmode = string.Empty;
            cmdObj = new MySqlCommand();
            cmdObj.CommandText = "getEditableData";

            cmdObj.Parameters
                .Add(new MySqlParameter("@Uid", MySqlDbType.LongText))
                .Value = user.Trim();


            DataTable dt = new DataTable();
            dt = du.GetDataTableWithProc(cmdObj);

            var sites = DataTableToJSONWithJavaScriptSerializer(dt);
            return Json(sites, JsonRequestBehavior.AllowGet);
        }
        public ActionResult Reset_Password(string email, string pass)
        {
            MySqlParameter result = new MySqlParameter("@result", MySqlDbType.VarChar, 100) { Direction = ParameterDirection.Output };
            MySqlParameter email_id = new MySqlParameter("@email", MySqlDbType.VarChar, 100) { Direction = ParameterDirection.Output };
            MySqlParameter FirstName = new MySqlParameter("@Fst", MySqlDbType.VarChar, 100) { Direction = ParameterDirection.Output };
            MySqlParameter LastName = new MySqlParameter("@Lst", MySqlDbType.VarChar, 100) { Direction = ParameterDirection.Output };
            //Commented by Manimekalai on 23062020 to update password from UI
            //string pass = Convert.ToBase64String(Guid.NewGuid().ToByteArray()).Substring(0, 8);
            DataUtility du = new DataUtility();
            string opmode = string.Empty;
            cmdObj = new MySqlCommand();
            cmdObj.CommandText = "getResetPassword";

            cmdObj.Parameters
                .Add(new MySqlParameter("@Uid", MySqlDbType.LongText))
                .Value = email.Trim();
            cmdObj.Parameters
                .Add(new MySqlParameter("@Pass", MySqlDbType.LongText))
                .Value = pe.Encrypt(pass.Trim());
            cmdObj.Parameters.Add(result);
            cmdObj.Parameters.Add(email_id);
            cmdObj.Parameters.Add(FirstName);
            cmdObj.Parameters.Add(LastName);
            du.ExecuteSqlProcedure(cmdObj);
            var status = result.Value.ToString();
            //Commented by Manimekalai on 23062020. As per requirement here we are verifiying capcha and updating pwd directly to database.
            //if (status == "Your password has been changed and send to your register mail so please check your mail id.")
            //{
            //    //var email_flag = Email(email_id.Value.ToString(), "duvesh.varshney@teamcomputers.com", pass);
            //    var email_flag = Email_new(email_id.Value.ToString(), "smaarthelpdesk@hondacarindia.com", pass,FirstName.Value.ToString(),LastName.Value.ToString(),email);
            //}
            return Json(status, JsonRequestBehavior.AllowGet);
        }
        public bool Email(string tomail_id, string frommail_id, string pass)
        {
            try
            {
                MailMessage objeto_mail = new MailMessage();
                SmtpClient client = new SmtpClient();
                //client.Port = 25;
                client.Port = 587;
                client.Host = "smtp.gmail.com";
                client.Timeout = 10000;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.EnableSsl = true;
                client.Credentials = new System.Net.NetworkCredential("smaarthelpdesk@hondacarindia.com", "password@1");

                objeto_mail.From = new MailAddress(frommail_id, "Alert");
                objeto_mail.To.Add(new MailAddress(tomail_id));
                objeto_mail.Subject = "Reset Password";
                //objeto_mail.Body = "Your password has been changed.Now your password is "+pass;
                objeto_mail.Body = "Dear Concerned, \r\n" + "Your password has been changed.Now your password is " + pass + " \r\n" + "Thank you,\r\n" + "TCPL Support Team";
                client.Send(objeto_mail);
                return true;
            }
            catch (Exception ex)
            { writeLog(ex.Message); return false; }
        }
        public bool Email_new(string tomail_id, string frommail_id, string pass, string FirstName, string LastName, string Uid)
        {
            try
            {
                MailMessage objeto_mail = new MailMessage();
                SmtpClient client = new SmtpClient();
                client.Port = 25;
                //client.Port = 587;
                client.Host = "172.18.1.231";
                //var Domain = tomail_id.Split('@');
                //if (Domain[1] == "hondacarindia.com")
                //{
                //    client.Host = "10.​116.​106.​6";
                //}
                //else
                //{
                //    client.Host = "10.117.22.43";
                //}
                client.Timeout = 5000;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.EnableSsl = false;
                client.Credentials = new System.Net.NetworkCredential("smaarthelpdesk@hondacarindia.com", "password@1");

                objeto_mail.From = new MailAddress(frommail_id, "Honda SMAART Helpdesk");
                objeto_mail.To.Add(new MailAddress(tomail_id));
                objeto_mail.IsBodyHtml = true;
                objeto_mail.Subject = "Password for Honda SMAART " + Uid + " (" + FirstName + " " + LastName + ")";
                //objeto_mail.Body = "Your password has been changed.Now your password is "+pass;
                objeto_mail.Body = "<table><tbody><tr><td>Dear " + FirstName + " " + LastName + ",<br /><br />The Password for your Honda SMAART account, with user ID " + Uid + " has been reset.<br /><br />Your New Password is: <b> " + pass + "</b>.<br /><br />You’ll be prompted to reset this password to your own on first time login.<br /><br />Additionally, you can change your password by using the following steps within the Honda SMAART application:<br />Step-1: Log in to Honda SMAART application.<br />Step-2: Click on the User Management icon on the top of the page.<br />Step-3: Click on Change Password.<br />Step-4: Enter Old Password and New Password.<br />Step-5: Click on Submit.<br /><br />In case you need any help, you can contact the SMAART Helpdesk Team by replying to this email (smaarthelpdesk@hondacarindia.com).<br /><br />Regards,<br />Honda SMAART Helpdesk <br /></td></tr></tbody></table>";
                client.Send(objeto_mail);
                return true;
            }
            catch (Exception ex)
            { writeLog(ex.Message); return false; }
        }
        private string TicketRequest(string method, string server, string virtualProxy, string user, string userdirectory, string port_tkt)
        {
            try
            {


                //   string url = "http://localhost:3000/auth/?";
                //   ticketURL
                string NodeURL = ConfigurationManager.ConnectionStrings["ticketURL"].ToString();
                var url = NodeURL + "?UserDirectory=" + userdirectory + "&UserId=" + user;//Paste ur url here  

                WebRequest request = HttpWebRequest.Create(url);

                WebResponse response = request.GetResponse();

                StreamReader reader = new StreamReader(response.GetResponseStream());

                string responseText = reader.ReadToEnd();
                return responseText;
                //Create the HTTP Request and add required headers and content in Xrfkey
                //string Xrfkey = "0123456789abcdef";



            }
            catch (Exception ex)
            {
                string dataused = method + "," + server + "," + virtualProxy + "," + user + "," + userdirectory + "," + port_tkt;
                System.IO.File.WriteAllText(System.AppDomain.CurrentDomain.BaseDirectory + @"\TicketRequest.txt", ex.Message.ToString() + " |||   " + dataused);
                return null;
            }

            /* try
            {
                X509Certificate2 certificateFoo = null;
                // First locate the Qlik Sense certificate
                X509Store store = new X509Store(StoreName.My, StoreLocation.LocalMachine);
                store.Open(OpenFlags.ReadOnly);
                certificateFoo = store.Certificates.Cast<X509Certificate2>().FirstOrDefault(c => c.FriendlyName == "QlikClient");
                store.Close();
                //The following line is required because the root certificate for the above server certificate is self-signed.
                //Using a certificate from a trusted root certificate authority will allow this line to be removed.
                ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };

                //Create URL to REST endpoint for tickets
                string url = host_Typ + "://" + server + ":" + port_tkt + "/qps/" + virtualProxy + "/ticket";
                //Create the HTTP Request and add required headers and content in Xrfkey
                string Xrfkey = "0123456789abcdef";
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url + "?Xrfkey=" + Xrfkey);
                // Add the method to authentication the user
                request.ClientCertificates.Add(certificateFoo);
                request.Method = method;
                request.Accept = "application/json";
                request.Headers.Add("X-Qlik-Xrfkey", Xrfkey);
                //The body message sent to the Qlik Sense Proxy api will add the session to Qlik Sense for authentication
                string body = "{ 'UserId':'" + user + "','UserDirectory':'" + userdirectory + "',";
                body += "'Attributes': [],";
                body += "}";
                byte[] bodyBytes = Encoding.UTF8.GetBytes(body);

                if (!string.IsNullOrEmpty(body))
                {
                    request.ContentType = "application/json";
                    request.ContentLength = bodyBytes.Length;
                    Stream requestStream = request.GetRequestStream();
                    requestStream.Write(bodyBytes, 0, bodyBytes.Length);
                    requestStream.Close();
                }

                // make the web request and return the content
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream stream = response.GetResponseStream();
                return stream != null ? new StreamReader(stream).ReadToEnd() : string.Empty;
            }
            catch (Exception ex)
            {
                return null;
            }
   */
        }
        private string Get_Ticket()
        {
            try
            {
                string ticketresponse = TicketRequest(method, tkthost, "header", Session["Uid"].ToString(), userdirectory, port_tkt);
                return ticketresponse
;
                //Parse the response
              /*  string[] getTicket = ticketresponse.Split(new Char[] { ',' });
                string[] getTicketCode = getTicket[3].Split(new Char[] { ':' });
                string Tickets = getTicketCode[1].Trim(new Char[] { '"' });
                return Tickets;
              */
            }
            catch
            {
                return null;
            }
        }
        [HttpPost]
        public ActionResult Image_Upload(FormCollection coll, HttpPostedFileBase file)
        {
            ImageSave(file);
            if (Session["Type"].ToString().Trim() == "admin")
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                return RedirectToAction("IndexUser", "Home");
            }

        }
        public void ImageSave(HttpPostedFileBase file)
        {
            if (file != null && file.ContentLength > 0)
                try
                {
                    string path = Path.Combine(Server.MapPath("~/assets/profile"),
                                               Path.GetFileName(Session["Uid"].ToString().Trim() + ".jpg"));
                    file.SaveAs(path);
                    // ViewBag.Message = "File uploaded successfully";
                }
                catch (Exception ex)
                {
                    writeLog(ex.Message);
                }
            else
            {

            }
        }
        public string DataTableToJSONWithJavaScriptSerializer(DataTable table)
        {
            JavaScriptSerializer jsSerializer = new JavaScriptSerializer();
            List<Dictionary<string, object>> parentRow = new List<Dictionary<string, object>>();
            Dictionary<string, object> childRow;
            foreach (DataRow row in table.Rows)
            {
                childRow = new Dictionary<string, object>();
                foreach (DataColumn col in table.Columns)
                {
                    childRow.Add(col.ColumnName, row[col]);
                }
                parentRow.Add(childRow);
            }
            return jsSerializer.Serialize(parentRow);
        }

        public void writeLog(string ex)
        {
            try
            {
                string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
                message += Environment.NewLine;
                message += "-----------------------------------------------------------";
                message += Environment.NewLine;
                message += string.Format("Message: {0}", ex);
                message += Environment.NewLine;
                message += "-----------------------------------------------------------";
                message += Environment.NewLine;
                string path = System.AppDomain.CurrentDomain.BaseDirectory + @"\Log.txt";
                using (StreamWriter writer = new StreamWriter(path, true))
                {
                    writer.WriteLine(message);
                    writer.Close();
                }
            }
            catch
            {
                throw;
            }
        }
    }
}