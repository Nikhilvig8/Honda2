﻿using DataUtilityLayer;
using Honda.Models;
using MySql.Data.MySqlClient;
using QlikAuthNet;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace Honda.Controllers
{
    [HandleError()]
    public class LoginController : Controller
    {
        // GET: Login
        static int attempt = 1;
        static string user_name = string.Empty;
        string method = ConfigurationManager.ConnectionStrings["method"].ToString();
        string host = ConfigurationManager.ConnectionStrings["host"].ToString();
        string host_Typ= ConfigurationManager.ConnectionStrings["hostType"].ToString();
        // string username = ConfigurationManager.ConnectionStrings["username"].ToString();
        string userdirectory = ConfigurationManager.ConnectionStrings["userdirectory"].ToString();
        string port = ConfigurationManager.ConnectionStrings["port"].ToString();
        string port_tkt = ConfigurationManager.ConnectionStrings["port_tkt"].ToString();
        string tkthost = ConfigurationManager.ConnectionStrings["tkthost"].ToString();

        public string conn = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
        MySqlCommand cmdObj;
        PassEncrypt pe = new PassEncrypt();


        public ActionResult Login()
        {
            writeLog("Function Login");

            //string captcha = CaptchaHelper.GenerateRandomCode();
            //Session["Captcha"] = captcha;

            //var imageBytes = CaptchaHelper.GenerateCaptchaImage(captcha);
            //return File(imageBytes, "image/png");


            return View();
        }

            public ActionResult CaptchaImage()
        {
            string captcha = CaptchaHelper.GenerateRandomCode();
            Session["Captcha"] = captcha;

            var imageBytes = CaptchaHelper.GenerateCaptchaImage(captcha);
            return File(imageBytes, "image/png");
        }

        public ActionResult ForgotPassword()
        {
            Session["Popup"] = null;
            Session["UserValid"] = null;
            return View();
        }

        public ActionResult NotValid()
        {
            Session["Popup"] = null;
            Session["UserValid"] = null;
            return View();
        }

        public ActionResult ResetPassword()
        {
            string sToken = Request.QueryString["token"];
            string sActualData = string.Empty;
            string status = string.Empty;
            if (sToken != null)
            {
                string sMinutes = ConfigurationManager.ConnectionStrings["ExpMinutes"].ToString();
                sActualData = pe.Decrypt(sToken);
                string[] strArray = sActualData.Split(',');
                status = strArray[0].ToString();
                string sRDate = strArray[1].ToString();
                if (DateTime.Now > DateTime.Parse(sRDate).AddMinutes(Convert.ToDouble(sMinutes)))
                {

                    status = "Password already reset or link expired!";
                    string sResetlink = ConfigurationManager.ConnectionStrings["Resetlink"].ToString() + "Login/NotValid";
                    Response.Redirect(sResetlink, false);
                }
                else
                {
                    Session["UserName"] = status;
                    string sResetlink = ConfigurationManager.ConnectionStrings["Resetlink"].ToString() + "Login/ForgotPassword";
                    Response.Redirect(sResetlink, false);
                }
            }
            return Json(status, JsonRequestBehavior.AllowGet);
        }

        public ActionResult TDashboard()
        {
            return View();
        }

        public ActionResult MfaMode()
        {
            if (Session["Email"] != null && !string.IsNullOrWhiteSpace(Session["Email"].ToString()))
            {
                DateTime? latestCreatedAt = GetLatestCreatedAtByUserId(Convert.ToInt32(Session["UserId"].ToString()));

                if (latestCreatedAt.HasValue)
                {
                    // Example: OTP created just now, expires in 5 minutes
                    DateTime otpCreatedAt = DateTime.UtcNow;
                    DateTime otpExpiresAt = otpCreatedAt.AddMinutes(5);
                    DateTime dateTime = (latestCreatedAt.Value).AddMinutes(5);
                    ViewBag.OtpExpiresAt = dateTime.ToString("o"); // ISO format for JavaScript parsing
                    return View();
                }
                else { return RedirectToAction("Login", "Login"); }
            }
            else
            {
                return View();
            }
        }
        
        [HttpPost]
        public ActionResult ResendOTP(FormCollection collection, string MFAButton)
        {   //resendotp       backlogin
            //submitButton= collection.Get("submitButton").ToString();
            
            switch (MFAButton)
            {
                case "resendotp":
                    var email = Session["Email"].ToString();
                    if (SendCodeToEmail(Session["Email"].ToString(), Convert.ToInt32(Session["UserId"].ToString())))
                    {
                        //Session["UserName"] = user.UserName;
                        //Session["RememberMe"] = user.RememberMe;
                        return RedirectToAction("MfaMode", "Login");
                    }
                    else
                    {
                        return RedirectToAction("Login", "Login");
                    }
                case "backlogin":
                    return RedirectToAction("Login", "Login");
                default:
                    return RedirectToAction("Login", "Login");
            }
            
        }
        [HttpPost]
        public ActionResult VerifyOtp(FormCollection collection, string submitButton)
        {
            string UserType = string.Empty;
            string emailotp = collection.Get("otp").ToString();
            int userId = Convert.ToInt32(Session["UserId"].ToString());
            var email = Session["Email"].ToString();
            if (VerifyEmailOtp(userId, emailotp))
            {
                FormsAuthentication.SetAuthCookie(Session["UserName"].ToString(),Convert.ToBoolean(Session["RememberMe"]));
                UserType = Session["Type"].ToString();
                attempt = 0;
                Session["attempt"] = null;
                Session["Popup"] = "1";
                if (Session["ftlf"].ToString() == "0")
                {
                    writeLog("firstlogin");
                    return RedirectToAction("first_login_Password", "Home");
                }
                else
                {
                    writeLog("Getting ticket");
                    //Session["Url"] = "http://iamsrinu.com/bluemoon2.1/";

                    //For Dashboard 
                    string ticket = Get_Ticket();
                    writeLog("QlikTicket:" + ticket);
                    Session["QlikTicket"] = ticket;
                    System.IO.File.WriteAllText(System.AppDomain.CurrentDomain.BaseDirectory + @"\ticket.txt", ticket);
                    //string Url = "https://" + host +"/ header/hub?qlikTicket=" + ticket;
                    //Here we changed SSL as normal
                    string Url = host_Typ + "://" + host + port + "/header/hub?qlikticket=" + ticket;

                    //                        string ticket = getTicket(Session["Uid"].ToString());
                    //                        string Url = "https://smaart.hondacarindia.com/header/hub?" + ticket; 

                    // For Demo
                    // string Url = "https://demos.qlik.com/qliksense";
                    Session["Url"] = Url;
                    Session["Optype"] = "dash";
                    writeLog("calling iframe:" + Url + "with mapping:" + Session["Mapping"].ToString());
                    return RedirectToAction("iframeIndex", "Home", new { Mapping = Session["Mapping"].ToString() });
                }
            }
           return View();
        }
        [HttpPost]

        public ActionResult LoginCheck(FormCollection collection, string submitButton)
        {
            Session["Popup"] = null;
            Session["UserValid"] = null;
            writeLog("Clicked:" + submitButton);
            var sVal = pe.Decrypt("A75ttN1ZV1yHOCU/w7RShFRuOBsr8n7ehRTzQY+P7+w=");
            switch (submitButton)
            {
                case "Login":
                    return LoginData(collection);
                  case "Forgot Password":
                    return ForgotData(collection);
                default:
                     return View();
                    //return RedirectToAction("Login", "Login");
            }

        }

        private ActionResult LoginData(FormCollection collection)
        {
            writeLog("LoginData function");
            string UserType = string.Empty;
            string status = string.Empty;
            Users user = new Users();
            user.UserName = collection.Get("username").ToString();
            user.Password = collection.Get("password").ToString();
            user.userCaptcha=collection.Get("userCaptcha").ToString();
            string sessionCaptcha = Session["Captcha"] as string;

            if (user.userCaptcha == sessionCaptcha)
            {
            Session["Popup"] = null;
            Session["UserValid"] = null;
            if (ModelState.IsValid)
            {
                if (user.IsValid(user.UserName, user.Password))
                {
                    
                    writeLog("Valid user");
                    int userId = Convert.ToInt32(Session["UserId"].ToString());
                    var sVal = pe.Decrypt("A75ttN1ZV1yHOCU/w7RShFRuOBsr8n7ehRTzQY+P7+w=");
                    Session["UserName"] = user.UserName;
                    bool _mfa = CheckUserExists(userId);

                    if (_mfa) {

                        if (SendCodeToEmail(Session["Email"].ToString(),userId))
                        {
                            
                            Session["RememberMe"] = user.RememberMe;
                            return RedirectToAction("MfaMode");
                        }
                        else
                        {
                            FormsAuthentication.SetAuthCookie(user.UserName, user.RememberMe);
                            UserType = Session["Type"].ToString();
                            attempt = 0;
                            Session["attempt"] = null;
                            Session["Popup"] = "1";
                            if (Session["ftlf"].ToString() == "0")
                            {
                                writeLog("firstlogin");
                                return RedirectToAction("first_login_Password", "Home");
                            }
                            else
                            {
                                writeLog("Getting ticket");
                                //Session["Url"] = "http://iamsrinu.com/bluemoon2.1/";

                                //For Dashboard 
                                string ticket = Get_Ticket();
                                writeLog("QlikTicket:" + ticket);
                                Session["QlikTicket"] = ticket;
                                System.IO.File.WriteAllText(System.AppDomain.CurrentDomain.BaseDirectory + @"\ticket.txt", ticket);
                                //string Url = "https://" + host +"/ header/hub?qlikTicket=" + ticket;
                                //Here we changed SSL as normal
                                string Url = host_Typ + "://" + host + port + "/header/hub?qlikticket=" + ticket;

                                //                        string ticket = getTicket(Session["Uid"].ToString());
                                //                        string Url = "https://smaart.hondacarindia.com/header/hub?" + ticket; 

                                // For Demo
                                // string Url = "https://demos.qlik.com/qliksense";
                                Session["Url"] = Url;
                                Session["Optype"] = "dash";
                                writeLog("calling iframe:" + Url + "with mapping:" + Session["Mapping"].ToString());
                                return RedirectToAction("iframeIndex", "Home", new { Mapping = Session["Mapping"].ToString() });
                            }
                        }

                        
                    }
                    else
                    {
                        FormsAuthentication.SetAuthCookie(user.UserName, user.RememberMe);
                        UserType = Session["Type"].ToString();
                        attempt = 0;
                        Session["attempt"] = null;
                        Session["Popup"] = "1";
                        if (Session["ftlf"].ToString() == "0")
                        {
                            writeLog("firstlogin");
                            return RedirectToAction("first_login_Password", "Home");
                        }
                        else
                        {
                            writeLog("Getting ticket");
                            //Session["Url"] = "http://iamsrinu.com/bluemoon2.1/";

                            //For Dashboard 
                            string ticket = Get_Ticket();
                            writeLog("QlikTicket:" + ticket);
                            Session["QlikTicket"] = ticket;
                            System.IO.File.WriteAllText(System.AppDomain.CurrentDomain.BaseDirectory + @"\ticket.txt", ticket);
                            //string Url = "https://" + host +"/ header/hub?qlikTicket=" + ticket;
                            //Here we changed SSL as normal
                            string Url = host_Typ + "://" + host + port + "/header/hub?qlikticket=" + ticket;

                            //                        string ticket = getTicket(Session["Uid"].ToString());
                            //                        string Url = "https://smaart.hondacarindia.com/header/hub?" + ticket; 

                            // For Demo
                            // string Url = "https://demos.qlik.com/qliksense";
                            Session["Url"] = Url;
                            Session["Optype"] = "dash";
                            writeLog("calling iframe:" + Url + "with mapping:" + Session["Mapping"].ToString());
                            return RedirectToAction("iframeIndex", "Home", new { Mapping = Session["Mapping"].ToString() });
                        }
                    }
                }
                else
                {
                    //ModelState.AddModelError("", "Login data is incorrect!");

                    if (user_name != user.UserName)
                    {
                        user_name = user.UserName;
                        attempt = 1;

                        Session["Popup"] = "0";

                        if (attempt >= 10)
                        {
                            writeLog("Updating Active Status");
                            attempt = 0;
                            Session["attempt"] = null;
                            user_name = string.Empty;
                           user.UpdateUserStatus(user.UserName);
                            status = "Your Account is Inactivated.Contact Admin!!!";
                            Session["UserValid"] = status;
                            return RedirectToAction("Login", "Login");
                           // return RedirectToAction("ForgotPassword", "Login");
                        }
                        else
                        {

                            Session["attempt"] = attempt;
                            attempt++;
                            return RedirectToAction("Login", "Login");
                        }

                    }
                    else
                    {
                        Session["Popup"] = "0";

                        if (attempt >= 10)
                        {
                            writeLog("Updating Active Status");
                            attempt = 0;
                            Session["attempt"] = null;
                            user_name = string.Empty;
                            user.UpdateUserStatus(user.UserName);
                              status = "Your Account is Inactivated.Contact Admin!!!";
                            Session["UserValid"] = status;
                            return RedirectToAction("Login", "Login");
                           // return RedirectToAction("ForgotPassword", "Login");
                        }
                        else
                        {

                            Session["attempt"] = attempt;
                            attempt++;
                            return RedirectToAction("Login", "Login");
                        }
                    }
                }
            }
            return View(user);
                //ViewBag.Message = "CAPTCHA Verified!";
            }
            else
            {
                ViewBag.Message = "Invalid CAPTCHA!";
                return View("Login");
            }

        }

        private ActionResult ForgotData(FormCollection collection)
        {
            writeLog("ForgotData function");
             Users user = new Users();
            user.UserName = collection.Get("username").ToString();
            user.Password = collection.Get("password").ToString();
            string sUSer = collection.Get("username").ToString();
            string status = string.Empty;
            Session["Popup"] = null;
            Session["UserValid"] = null;
            string sErrDesc = string.Empty;
            writeLog("UserName:" + sUSer);
            writeLog("Pwd:" + collection.Get("password").ToString());

            if (sUSer != "" && sUSer != "undefined")
            {
                MySqlParameter result = new MySqlParameter("@result", MySqlDbType.VarChar, 100) { Direction = ParameterDirection.Output };
                MySqlParameter email_id = new MySqlParameter("@mail", MySqlDbType.VarChar, 100) { Direction = ParameterDirection.Output };

                DataUtility du = new DataUtility();
                string opmode = string.Empty;
                cmdObj = new MySqlCommand();
                cmdObj.CommandText = "getUserDetails";

                cmdObj.Parameters
                    .Add(new MySqlParameter("@UserName", MySqlDbType.LongText))
                    .Value = sUSer.Trim();
                cmdObj.Parameters.Add(result);
                cmdObj.Parameters.Add(email_id);
                du.ExecuteSqlProcedure(cmdObj);
                writeLog("SP result:" + result.Value + "_" + email_id.Value);
                if (result.Value.ToString() == "Valid user.")
                {
                   
                    if (email_id.Value.ToString() != "")
                    {
                        var email_flag = Email_ResetLink(email_id.Value.ToString().Trim(), "", "", sUSer,ref sErrDesc);
                        if (email_flag == true)
                        {
                            status = "Reset password sent to your mailid: " + email_id.Value.ToString();
                            Session["UserValid"] = status;
                            return RedirectToAction("Login", "Login");
                        }
                        else
                        {
                            status = sErrDesc.Trim();
                            Session["UserValid"] = status;
                            return RedirectToAction("Login", "Login");

                        }
                    }
                    else
                    {
                        status = "Your E-Mail not configured";
                        Session["UserValid"] = status;
                        return RedirectToAction("Login", "Login");

                    }
                        
                }
                else
                {
                    status = result.Value.ToString();
                    Session["UserValid"] = status;
                    return RedirectToAction("Login", "Login");

                }

            }
            else
            {
                
                status = "Must enter UserName";
                Session["UserValid"] = status;
                return RedirectToAction("Login", "Login");

            }
            //return View(user);
           // return RedirectToAction("Login", "Login");
        }

        public void writeLog(string ex)
        {
            try
            {
                string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
                message += Environment.NewLine;
                message += "-----------------------------------------------------------";
                message += Environment.NewLine;
                message += string.Format("Message: {0}", ex);
                message += Environment.NewLine;
                message += "-----------------------------------------------------------";
                message += Environment.NewLine;
                string path = System.AppDomain.CurrentDomain.BaseDirectory + @"\Log.txt";
                using (StreamWriter writer = new StreamWriter(path, true))
                {
                    writer.WriteLine(message);
                    writer.Close();
                }
            }
            catch
            {
                throw;
            }
        }
        public bool Email_ResetLink(string tomail_id, string FirstName, string LastName, string user,ref string sErrDesc)
        {
            try
            {
                MailMessage objeto_mail = new MailMessage();
                SmtpClient client = new SmtpClient();
                string sUserCurDat = user + "," + DateTime.Now.ToString();
                string sSMTPUserName = ConfigurationManager.ConnectionStrings["SMTPUserName"].ToString();
                string sSMTPPwd = ConfigurationManager.ConnectionStrings["SMTPPassword"].ToString();
                string sFrommail = ConfigurationManager.ConnectionStrings["FromEmail"].ToString();
                string sDispNam = ConfigurationManager.ConnectionStrings["MailName"].ToString();
                string sResetlink = ConfigurationManager.ConnectionStrings["Resetlink"].ToString() + "Login/ResetPassword?token=" + pe.Encrypt(sUserCurDat);
                string sSubject = ConfigurationManager.ConnectionStrings["MailSubject"].ToString();
                string sRegards = ConfigurationManager.ConnectionStrings["MailRegards"].ToString();
                //var Domain = tomail_id.Split('@');
                //if (Domain[1] == "hondacarindia.com")
                //{
                //    client.Host = "10.​116.​106.​6";
                //}
                //else
                //{
                //    client.Host = "10.117.22.43";
                //}
                client.Credentials = new System.Net.NetworkCredential(sSMTPUserName, sSMTPPwd);
                client.Port = Convert.ToInt32(ConfigurationManager.ConnectionStrings["SMTPPort"].ToString());
                client.Host = ConfigurationManager.ConnectionStrings["SMTPServer"].ToString();
                client.EnableSsl = Convert.ToBoolean(ConfigurationManager.ConnectionStrings["EnableSSL"].ToString()); 

                objeto_mail.From = new MailAddress(sFrommail,sDispNam);
                objeto_mail.To.Add(new MailAddress(tomail_id));
                objeto_mail.IsBodyHtml = true;
                objeto_mail.Subject = sSubject;
                objeto_mail.Body = "<table><tbody><tr><td>Hi " + user + " " + LastName + ",<br /><br />You recently requested to reset the password.<br />" +
                "<br /><left>Click here to &nbsp;<a style=" + "\"text-decoration:none; color:maroon;font-weight:bold;font-size:16px;\" href=" + sResetlink + "><b>Reset your password</b></a></left><br/><br/>Regards,<br />" + sRegards + "<br /></td></tr></tbody></table>";
                //objeto_mail.Body = "Your password has been changed.Now your password is "+pass;
                //objeto_mail.Body = "<table><tbody><tr><td>Hi " + user + " " + LastName + ",<br /><br />You recently requested to reset the password.Click the button below to reset it.<br />" +
                //    "<br /><center><button style=\"height:30px; background-color:royalblue;border:none;font-weight: bold;\" &nbsp; type=\"submit\"><a style=" + "\"text-decoration:none; color:white;\" href=" + sResetlink + ">Reset your password</a></button></center><br/><br/>If you are having trouble clicking the reset button, copy and paste below URL into your browser. <br/>"+ sResetlink +"<br/><br/>Regards,<br />" + sRegards + "<br /></td></tr></tbody></table>";
                client.Send(objeto_mail);
                return true;
            }
            
            catch (Exception ex)
            { 
                sErrDesc= ex.Message.ToString();
                return false;
            }
            
        }
        public ActionResult VeryfiyClientApp(string Macadd)
        {
            string VFlag = string.Empty;
            Users user = new Users();
            if (user.VeryfiyMac(Macadd))
            {
                VFlag = "True";
            }
            else
            {
                VFlag = "False";
            }
            return Json(VFlag, JsonRequestBehavior.AllowGet);
        }
        private string TicketRequest(string method, string server, string virtualProxy, string user, string userdirectory, string port_tkt)
        {
            try
            {


                //   string url = "http://localhost:3000/auth/?";
                //   ticketURL
                string NodeURL = ConfigurationManager.ConnectionStrings["ticketURL"].ToString();
                var url = NodeURL  + "?UserDirectory=" + userdirectory + "&UserId=" + user;//Paste ur url here  

                WebRequest request = HttpWebRequest.Create(url);

                WebResponse response = request.GetResponse();

                StreamReader reader = new StreamReader(response.GetResponseStream());

                string responseText = reader.ReadToEnd();
                return responseText;
                //Create the HTTP Request and add required headers and content in Xrfkey
                //string Xrfkey = "0123456789abcdef";
              


            }
            catch (Exception ex)
            {
                string dataused = method + "," + server + "," + virtualProxy + "," + user + "," + userdirectory + "," + port_tkt;
                System.IO.File.WriteAllText(System.AppDomain.CurrentDomain.BaseDirectory + @"\TicketRequest.txt", ex.Message.ToString() + " |||   " + dataused);
                return null;
            }

        }

        private string Get_Ticket()
        {
            try
            {
                string ticketresponse = TicketRequest(method, tkthost, "header", Session["Uid"].ToString(), userdirectory, port_tkt);
                return ticketresponse;
                //Parse the response
               // string[] getTicket = ticketresponse.Split(new Char[] { ',' });
              //  string[] getTicketCode = getTicket[3].Split(new Char[] { ':' });
              //  string Tickets = getTicketCode[1].Trim(new Char[] { '"' });
               // return Tickets;
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }

        //public new bool check_send_otp_for_mfa(int userid)
        //{

        //    //using (var cn = new MySqlConnection(conn))
        //    //{
        //    //    string _sql = @"checkUserforMfa";
        //    //    var cmd = new MySqlCommand(_sql, cn);
        //    //    cmd.CommandType = CommandType.StoredProcedure;
        //    //    cmd.Parameters
        //    //        .Add(new MySqlParameter("@u", MySqlDbType.LongText))
        //    //        .Value = _username;
        //    //    cmd.Parameters
        //    //        .Add(new MySqlParameter("@p", MySqlDbType.LongText))
        //    //        .Value = pe.Encrypt(_password);
        //    //    cn.Open();
        //    //    var reader = cmd.ExecuteReader();
        //    //    if (reader.HasRows)
        //    //    {
        //    //        while (reader.Read())
        //    //        {
        //    //            Session["Type"] = reader["Type"].ToString();
        //    //            Session["UserName"] = reader["Username"].ToString();
        //    //            Session["Uid"] = reader["Uid"].ToString();
        //    //            Session["ftlf"] = reader["ftlf"].ToString();
        //    //            Session["Mapping"] = reader["Mapping"].ToString();
        //    //            Session["UserId"] = reader["UserId"].ToString();
        //    //        }
        //    //        reader.Dispose();
        //    //        cmd.Dispose();
        //    //        return true;
        //    //    }
        //    //    else
        //    //    {
        //    //        reader.Dispose();
        //    //        cmd.Dispose();
        //    //        return false;
        //    //    }
        //    //}
        //    return false;
        //}


        public bool CheckUserExists(int userId)
        {
            using (var cn = new MySqlConnection(conn))
            {
                cn.Open();

                using (var cmd = new MySqlCommand("CheckUserExistsInMfaUser", cn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;

                    // Input parameter
                    var userIdParam = new MySqlParameter("p_user_id", MySqlDbType.Int32);
                    userIdParam.Direction = ParameterDirection.Input;
                    userIdParam.Value = userId;
                    cmd.Parameters.Add(userIdParam);

                    // Output parameter
                    var existsParam = new MySqlParameter("p_exists", MySqlDbType.Bit);
                    existsParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(existsParam);

                    // Execute
                    cmd.ExecuteNonQuery();

                    // Read output value safely
                    object result = existsParam.Value;

                    //if (result == DBNull.Value || result == null)
                    //    return false;

                    //if (result is bool b)
                    //    return b;

                    //if (result is byte byt)
                    //    return byt != 0;

                    //if (result is sbyte sbyt)
                    //    return sbyt != 0;

                    //if (result is byte[] byteArr && byteArr.Length > 0)
                    //    return byteArr[0] != 0;

                    return Convert.ToBoolean(result);
                }
            }
        }


        // Generate a 6-digit random integer as string
        public string Generate6DigitCode()
        {
            Random rnd = new Random();
            int code = rnd.Next(100000, 999999); // Ensures 6 digits
            return code.ToString();
        }

        // Send the code via email
        public bool SendCodeToEmail(string toEmail, int userId)
        {
            string fromEmail = "smaarthelpdesk@hondacarindia.com";
            string password = "password@1"; // Replace with actual secure password

            // Generate the code
            string code = Generate6DigitCode();

            bool inserted = InsertMfaCodes(userId, "", code);

            if (inserted)
            {
                // Send the email
                bool emailSent = EmailforMfa(toEmail, fromEmail, code, password);
                return emailSent;
            }
            // Optionally: save the code to database or session for later validation
            return false;
        }

        // Email sending function
        public bool EmailforMfa(string tomail_id, string frommail_id, string code, string pass)
        {
            try
            {
                MailMessage objeto_mail = new MailMessage();
                SmtpClient client = new SmtpClient();

                client.Port = 25;
                client.Host = "10.117.22.76";
                client.Timeout = 10000;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.EnableSsl = false;

                client.Credentials = new NetworkCredential(frommail_id, pass);

                objeto_mail.From = new MailAddress(frommail_id, "SMAART HELPDESK");
                objeto_mail.To.Add(new MailAddress(tomail_id));
                objeto_mail.To.Add(new MailAddress("rohit.singh@teamcomputers.com"));
                objeto_mail.Subject = "SMAART OTP Verification.";

                //objeto_mail.Body = "Dear Concerned,\r\n\r\n"
                //                 + "Your login MFA code is: " + code + "\r\n\r\n"
                //                 + "Thank you,\r\nTCPL Support Team";

                //objeto_mail.Body = "Hi Admin User,\r\n\r\n"
                //                 + "The verification code for <strong>" + Session["UserName"].ToString() + "</strong> user is  <strong>" + code + "</strong>. Please use it to continue your authentication to SMAART admin login.\r\n\r\n"
                //                 + "Note: \r\n"
                //                 + "1. You will need to request a new verification code if you do not use this code within 5 minutes.\r\n"
                //                 + "2. Add our email source as a trusted originator so that emails do not end up in your junk mail/spam folder.\r\n\r\n\r\n"
                //                 + "Thank you,\r\nTCPL Support Team";

                objeto_mail.IsBodyHtml = true;
                objeto_mail.Body =
    "Hi Admin User,<br/><br/>" +
    "The verification code for <strong>" + Session["UserName"].ToString() + "</strong> user is <strong>" + code + "</strong>. Please use it to continue your authentication to SMAART admin login.<br/><br/>" +
    "Note:<br/>" +
    "1. You will need to request a new verification code if you do not use this code within 5 minutes.<br/>" +
    "2. Add our email source as a trusted originator so that emails do not end up in your junk mail/spam folder.<br/><br/><br/>" +
    "Thank you,<br/>SMAART HELPDESK";

                client.Send(objeto_mail);
                return true;
            }
            catch (Exception ex)
            {
                writeLog(ex.Message);
                return true;
            }
        }

        public bool InsertMfaCodes(int userId, string mobileCode, string emailCode)
        {
            using (var cn = new MySqlConnection(conn))
            {
                cn.Open();

                bool CheckAndDeleteUserMfaRecord = CheckAndDeleteUserMfaRecords(userId);
                using (var cmd = new MySqlCommand("InsertMfaCodes", cn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new MySqlParameter("p_user_id", MySqlDbType.Int32) { Value = userId });
                    cmd.Parameters.Add(new MySqlParameter("p_mobile_code", MySqlDbType.VarChar) { Value = mobileCode });
                    cmd.Parameters.Add(new MySqlParameter("p_email_code", MySqlDbType.VarChar) { Value = emailCode });

                    int rowsAffected = cmd.ExecuteNonQuery();

                    return rowsAffected > 0;
                }
            }
        }
        public bool CheckUserIdExists(int userId)
        {
            bool exists = false;

            using (var cn = new MySqlConnection(conn))
            {
                cn.Open();

                using (var cmd = new MySqlCommand("CheckUserIdExists", cn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("p_user_id", userId);

                    var outputParam = new MySqlParameter("p_exists", MySqlDbType.Bit)
                    {
                        Direction = System.Data.ParameterDirection.Output
                    };
                    cmd.Parameters.Add(outputParam);

                    cmd.ExecuteNonQuery();

                    exists = Convert.ToBoolean(outputParam.Value);
                }
            }

            return exists;
        }
        public bool CheckAndDeleteUserMfaRecords(int userId)
        {
            bool deleted = false;

            using (var cn = new MySqlConnection(conn))
            {
                cn.Open();

                using (var cmd = new MySqlCommand("CheckAndDeleteUserMfaRecords", cn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("p_user_id", userId);

                    var outputParam = new MySqlParameter("p_deleted", MySqlDbType.Bit)
                    {
                        Direction = System.Data.ParameterDirection.Output
                    };
                    cmd.Parameters.Add(outputParam);

                    cmd.ExecuteNonQuery();

                    deleted = Convert.ToBoolean(outputParam.Value);
                }
            }

            return deleted;
        }
        public bool VerifyEmailOtp(int userId, string emailOtp)
        {
            bool isValid = false;

            using (var cn = new MySqlConnection(conn))
            {
                cn.Open();

                using (var cmd = new MySqlCommand("VerifyEmailOTP", cn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("p_user_id", userId);
                    cmd.Parameters.AddWithValue("p_email_code", emailOtp);

                    var outputParam = new MySqlParameter("p_is_valid", MySqlDbType.Bit)
                    {
                        Direction = System.Data.ParameterDirection.Output
                    };
                    cmd.Parameters.Add(outputParam);

                    cmd.ExecuteNonQuery();

                    isValid = Convert.ToBoolean(outputParam.Value);
                }
                cn.Close();
            }

            return isValid;
        }

        public DateTime? GetLatestCreatedAtByUserId(int userId)
        {
            DateTime? createdAt = null;

            using (var cn = new MySqlConnection(conn))
            {
                cn.Open();

                using (var cmd = new MySqlCommand("GetLatestCreatedAtByUserId", cn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("p_user_id", userId);

                    var outputParam = new MySqlParameter("p_created_at", MySqlDbType.DateTime)
                    {
                        Direction = System.Data.ParameterDirection.Output
                    };
                    cmd.Parameters.Add(outputParam);

                    cmd.ExecuteNonQuery();

                    if (outputParam.Value != DBNull.Value)
                    {
                        createdAt = Convert.ToDateTime(outputParam.Value);
                    }
                }
            }

            return createdAt;
        }
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login", "Login");
        }
    }

}