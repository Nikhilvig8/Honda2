﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using DataUtilityLayer;
using System.Configuration;
using Honda;
using System.Net;
using System.Xml;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using MySql.Data.MySqlClient;

namespace Honda.Models
{
    public class Users : DataUtilityLayer.DataUtility
    {
        PassEncrypt pe = new PassEncrypt();
        string conn = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
        MySqlCommand cmdObj;
        MySqlParameter prmObj;
        [Required]
        [Display(Name = "User name")]
        public string UserName { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [Display(Name = "Remember on this computer")]
        public bool RememberMe { get; set; }
        [Required]
        [Display(Name = "Type")]
        public string Type { get; set; }
        [Required]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Display(Name = "IsActive")]
        public string IsActive { get; set; }

        [Display(Name = "Contact")]
        public string Contact { get; set; }

        [Display(Name = "rID")]
        public string rID { get; set; }

        public string userCaptcha { get; set; }


        /// <summary>
        /// Checks if user with given password exists in the database
        /// </summary>
        /// <param name="_username">User name</param>
        /// <param name="_password">User password</param>
        /// <returns>True if user exist and password is correct</returns>
        /// bool valid = false;

        public bool VeryfiyMac(string mac)
        {
            using (var cn = new MySqlConnection(conn))
            {
                string _sql = "ValidateMac";
                var cmd = new MySqlCommand(_sql, cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters
                    .Add(new MySqlParameter("@mac1", MySqlDbType.LongText))
                    .Value = mac;

                cn.Open();
                var reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {

                        string un = reader["UN"].ToString();


                    }
                    reader.Dispose();
                    cmd.Dispose();
                    return true;
                }
                else
                {
                    reader.Dispose();
                    cmd.Dispose();
                    return false;
                }
            }
        }

        public bool UpdateUserStatus(string _username)
        {
           
                using (var cn = new MySqlConnection(conn))
                {
                    string _sql = @"UpdateUserStatus";
                    var cmd = new MySqlCommand(_sql, cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters
                        .Add(new MySqlParameter("@u", MySqlDbType.LongText))
                        .Value = _username;
                    cn.Open();
                    var reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            reader.Dispose();
                            cmd.Dispose();
                            cn.Close();
                            return true;
                        }
                    }
                    else
                    {
                        reader.Dispose();
                        cmd.Dispose();
                        cn.Close();
                        return false;
                    }
                }
              

            return true;
        }


        public new bool IsValid(string _username, string _password)
        {
           
            using (var cn = new MySqlConnection(conn))
            {
                string _sql = @"ValidateUser";
                var cmd = new MySqlCommand(_sql, cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters
                    .Add(new MySqlParameter("@u", MySqlDbType.LongText))
                    .Value = _username;
                cmd.Parameters
                    .Add(new MySqlParameter("@p", MySqlDbType.LongText))
                    .Value = pe.Encrypt(_password);
                cn.Open();
                var reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while(reader.Read())
                    { 
                    Session["Type"] = reader["Type"].ToString();
                    Session["UserName"]= reader["Username"].ToString();
                    Session["Uid"] = reader["Uid"].ToString();
                    Session["ftlf"] = reader["ftlf"].ToString();
                    Session["Mapping"] = reader["Mapping"].ToString();
                    Session["UserId"] = reader["UserId"].ToString();
                    Session["Email"] = reader["Email"].ToString();
                    }
                    reader.Dispose();
                    cmd.Dispose();
                    return true;
                }
                else
                {
                    reader.Dispose();
                    cmd.Dispose();
                    return false;
                }
            }
        }

        

    }
}