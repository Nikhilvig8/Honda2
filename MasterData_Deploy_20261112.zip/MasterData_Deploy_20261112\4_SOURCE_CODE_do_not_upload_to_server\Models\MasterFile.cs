using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security;
using System.Text;
using System.Xml;

namespace Honda.Models
{
    /// <summary>Problem with the uploaded file itself (not with a single row). Message is shown to the user.</summary>
    public class MasterFileException : Exception
    {
        public MasterFileException(string message) : base(message) { }
    }

    public class FileRow
    {
        public int RowNo { get; set; }          // row number as the user sees it in Excel / Notepad
        public string[] Cells { get; set; }
    }

    /// <summary>
    /// Reads and writes .csv and .xlsx without any extra NuGet package
    /// (only System.IO.Compression + System.Xml from .NET Framework).
    /// </summary>
    public static class MasterFile
    {
        public const int MaxFileBytes = 2 * 1024 * 1024;   // 2 MB
        public const int MaxDataRows = 5000;
        private const long MaxXmlPartBytes = 50L * 1024 * 1024;

        // ------------------------------------------------------------------ read

        public static List<FileRow> Read(Stream input, string fileName)
        {
            var ext = (Path.GetExtension(fileName ?? "") ?? "").ToLowerInvariant();
            byte[] bytes;
            using (var ms = new MemoryStream())
            {
                input.CopyTo(ms);
                bytes = ms.ToArray();
            }
            if (bytes.Length == 0)
                throw new MasterFileException("The selected file is empty.");
            if (bytes.Length > MaxFileBytes)
                throw new MasterFileException("The file is too large (" + (bytes.Length / 1024) + " KB). The maximum size is 2 MB.");

            bool looksLikeZip = bytes.Length > 4 && bytes[0] == 0x50 && bytes[1] == 0x4B; // "PK"
            if (ext == ".xlsx")
            {
                if (!looksLikeZip)
                    throw new MasterFileException("The file has a .xlsx name but is not a valid Excel workbook. Open it in Excel and use File > Save As > Excel Workbook (*.xlsx).");
                return ReadXlsx(bytes);
            }
            if (ext == ".csv")
            {
                if (looksLikeZip)
                    throw new MasterFileException("The file has a .csv name but is actually an Excel workbook. Rename it to .xlsx or save it as CSV.");
                return ReadCsv(bytes);
            }
            if (ext == ".xls")
                throw new MasterFileException("Old Excel 97-2003 (.xls) files are not supported. Open the file in Excel and save it as .xlsx or .csv.");
            throw new MasterFileException("Only .xlsx and .csv files can be uploaded.");
        }

        private static List<FileRow> ReadCsv(byte[] bytes)
        {
            string text;
            if (bytes.Length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF)
                text = Encoding.UTF8.GetString(bytes, 3, bytes.Length - 3);
            else if (bytes.Length >= 2 && bytes[0] == 0xFF && bytes[1] == 0xFE)
                text = Encoding.Unicode.GetString(bytes, 2, bytes.Length - 2);
            else
            {
                try { text = new UTF8Encoding(false, true).GetString(bytes); }
                catch (DecoderFallbackException) { text = Encoding.GetEncoding(1252).GetString(bytes); }
            }

            char delimiter = DetectDelimiter(text);
            var rows = new List<FileRow>();
            var cells = new List<string>();
            var cell = new StringBuilder();
            bool inQuotes = false;
            int line = 1, rowStartLine = 1;

            for (int i = 0; i < text.Length; i++)
            {
                char c = text[i];
                if (inQuotes)
                {
                    if (c == '"')
                    {
                        if (i + 1 < text.Length && text[i + 1] == '"') { cell.Append('"'); i++; }
                        else inQuotes = false;
                    }
                    else
                    {
                        if (c == '\n') line++;
                        cell.Append(c);
                    }
                    continue;
                }
                if (c == '"') { inQuotes = true; }
                else if (c == delimiter) { cells.Add(cell.ToString()); cell.Clear(); }
                else if (c == '\r') { /* handled with \n */ }
                else if (c == '\n')
                {
                    cells.Add(cell.ToString()); cell.Clear();
                    rows.Add(new FileRow { RowNo = rowStartLine, Cells = cells.ToArray() });
                    cells.Clear();
                    line++;
                    rowStartLine = line;
                }
                else cell.Append(c);
            }
            if (cell.Length > 0 || cells.Count > 0)
            {
                cells.Add(cell.ToString());
                rows.Add(new FileRow { RowNo = rowStartLine, Cells = cells.ToArray() });
            }
            return rows;
        }

        private static char DetectDelimiter(string text)
        {
            int end = text.IndexOf('\n');
            var first = end < 0 ? text : text.Substring(0, end);
            int commas = first.Count(ch => ch == ','), semis = first.Count(ch => ch == ';'), tabs = first.Count(ch => ch == '\t');
            if (semis > commas && semis >= tabs) return ';';
            if (tabs > commas && tabs > semis) return '\t';
            return ',';
        }

        private static List<FileRow> ReadXlsx(byte[] bytes)
        {
            try
            {
                using (var ms = new MemoryStream(bytes))
                using (var zip = new ZipArchive(ms, ZipArchiveMode.Read))
                {
                    var workbook = LoadXml(zip, "xl/workbook.xml");
                    if (workbook == null)
                        throw new MasterFileException("The Excel file could not be read (workbook part missing). Save it again as .xlsx and retry.");

                    var firstSheet = workbook.SelectSingleNode("//*[local-name()='sheets']/*[local-name()='sheet']") as XmlElement;
                    if (firstSheet == null)
                        throw new MasterFileException("The Excel file has no worksheets.");
                    string relId = firstSheet.GetAttribute("id", "http://schemas.openxmlformats.org/officeDocument/2006/relationships");

                    string sheetPath = "xl/worksheets/sheet1.xml";
                    var rels = LoadXml(zip, "xl/_rels/workbook.xml.rels");
                    if (rels != null && !string.IsNullOrEmpty(relId))
                    {
                        foreach (XmlElement rel in rels.SelectNodes("//*[local-name()='Relationship']"))
                        {
                            if (rel.GetAttribute("Id") == relId)
                            {
                                var target = rel.GetAttribute("Target").Replace('\\', '/');
                                sheetPath = target.StartsWith("/") ? target.TrimStart('/') : "xl/" + target;
                                break;
                            }
                        }
                    }

                    var shared = new List<string>();
                    var sst = LoadXml(zip, "xl/sharedStrings.xml");
                    if (sst != null)
                    {
                        foreach (XmlNode si in sst.SelectNodes("//*[local-name()='si']"))
                        {
                            var sb = new StringBuilder();
                            foreach (XmlNode t in si.SelectNodes(".//*[local-name()='t'][not(ancestor::*[local-name()='rPh'])]"))
                                sb.Append(t.InnerText);
                            shared.Add(DecodeExcelText(sb.ToString()));
                        }
                    }

                    var sheet = LoadXml(zip, sheetPath);
                    if (sheet == null)
                        throw new MasterFileException("The first worksheet of the Excel file could not be read.");

                    var rows = new List<FileRow>();
                    int seq = 0;
                    foreach (XmlElement row in sheet.SelectNodes("//*[local-name()='sheetData']/*[local-name()='row']"))
                    {
                        seq++;
                        int rowNo;
                        if (!int.TryParse(row.GetAttribute("r"), out rowNo)) rowNo = seq;
                        var values = new SortedDictionary<int, string>();
                        int nextCol = 0;
                        foreach (XmlElement c in row.SelectNodes("*[local-name()='c']"))
                        {
                            int col = ColumnIndex(c.GetAttribute("r"));
                            if (col < 0) col = nextCol;
                            nextCol = col + 1;
                            values[col] = CellText(c, shared);
                        }
                        int width = values.Count == 0 ? 0 : values.Keys.Max() + 1;
                        var cells = new string[width];
                        for (int i = 0; i < width; i++) cells[i] = values.ContainsKey(i) ? values[i] : "";
                        rows.Add(new FileRow { RowNo = rowNo, Cells = cells });
                    }
                    return rows;
                }
            }
            catch (MasterFileException) { throw; }
            catch (Exception)
            {
                throw new MasterFileException("The Excel file could not be read. It may be damaged or password-protected. Open it in Excel, save it again as .xlsx, and retry.");
            }
        }

        // Excel escapes some characters in cell text as _xHHHH_ (e.g. _x000D_ = carriage return)
        private static readonly System.Text.RegularExpressions.Regex XmlEscape =
            new System.Text.RegularExpressions.Regex("_x([0-9A-Fa-f]{4})_", System.Text.RegularExpressions.RegexOptions.Compiled);

        private static string DecodeExcelText(string s)
        {
            if (string.IsNullOrEmpty(s) || s.IndexOf("_x", StringComparison.Ordinal) < 0) return s;
            return XmlEscape.Replace(s, m => ((char)Convert.ToInt32(m.Groups[1].Value, 16)).ToString());
        }

        private static string CellText(XmlElement c, List<string> shared)
        {
            var type = c.GetAttribute("t");
            var vNode = c.SelectSingleNode("*[local-name()='v']");
            var v = vNode == null ? "" : vNode.InnerText;
            switch (type)
            {
                case "s":
                    int idx;
                    return int.TryParse(v, out idx) && idx >= 0 && idx < shared.Count ? shared[idx] : "";
                case "inlineStr":
                    var sb = new StringBuilder();
                    foreach (XmlNode t in c.SelectNodes(".//*[local-name()='t']")) sb.Append(t.InnerText);
                    return DecodeExcelText(sb.ToString());
                case "b":
                    return v == "1" ? "TRUE" : "FALSE";
                default:
                    return v;   // numbers / formula results as stored
            }
        }

        private static int ColumnIndex(string cellRef)
        {
            if (string.IsNullOrEmpty(cellRef)) return -1;
            int col = 0, i = 0;
            while (i < cellRef.Length && char.IsLetter(cellRef[i]))
            {
                col = col * 26 + (char.ToUpperInvariant(cellRef[i]) - 'A' + 1);
                i++;
            }
            return i == 0 ? -1 : col - 1;
        }

        private static XmlDocument LoadXml(ZipArchive zip, string path)
        {
            var entry = zip.Entries.FirstOrDefault(e => string.Equals(e.FullName.Replace('\\', '/'), path, StringComparison.OrdinalIgnoreCase));
            if (entry == null) return null;
            if (entry.Length > MaxXmlPartBytes)
                throw new MasterFileException("The Excel file is too large to process.");
            var settings = new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null };
            using (var s = entry.Open())
            using (var reader = XmlReader.Create(s, settings))
            {
                var doc = new XmlDocument { XmlResolver = null };
                doc.Load(reader);
                return doc;
            }
        }

        // ------------------------------------------------------------------ write

        public static byte[] WriteCsv(string[] headers, IEnumerable<string[]> rows)
        {
            var sb = new StringBuilder();
            sb.AppendLine(string.Join(",", headers.Select(CsvQuote)));
            foreach (var r in rows) sb.AppendLine(string.Join(",", r.Select(CsvQuote)));
            var preamble = Encoding.UTF8.GetPreamble();
            var body = Encoding.UTF8.GetBytes(sb.ToString());
            return preamble.Concat(body).ToArray();   // BOM so Excel opens it as UTF-8
        }

        private static string CsvQuote(string s)
        {
            return "\"" + (s ?? "").Replace("\"", "\"\"") + "\"";
        }

        /// <summary>Minimal single-sheet .xlsx: bold header row, all columns formatted as Text.</summary>
        public static byte[] WriteXlsx(string sheetName, string[] headers, IEnumerable<string[]> rows, int[] widths)
        {
            sheetName = new string((sheetName ?? "Sheet1").Where(ch => "[]:*?/\\".IndexOf(ch) < 0).ToArray());
            if (sheetName.Length > 31) sheetName = sheetName.Substring(0, 31);
            if (sheetName.Length == 0) sheetName = "Sheet1";

            var sheet = new StringBuilder();
            sheet.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
            sheet.Append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
            sheet.Append("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>");
            sheet.Append("<cols>");
            for (int i = 0; i < headers.Length; i++)
            {
                int w = widths != null && i < widths.Length ? widths[i] : 20;
                sheet.Append("<col min=\"" + (i + 1) + "\" max=\"" + (i + 1) + "\" width=\"" + w + "\" style=\"2\" customWidth=\"1\"/>");
            }
            sheet.Append("</cols><sheetData>");
            int r = 1;
            AppendRow(sheet, r++, headers, 1);
            foreach (var row in rows) AppendRow(sheet, r++, row, 2);
            sheet.Append("</sheetData></worksheet>");

            const string contentTypes = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
                "</Types>";
            const string rootRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                "</Relationships>";
            string workbook = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                "<sheets><sheet name=\"" + SecurityElement.Escape(sheetName) + "\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>";
            const string workbookRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
                "</Relationships>";
            // style 0 = default, 1 = bold header (text), 2 = text
            const string styles = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
                "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>" +
                "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>" +
                "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
                "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                "<cellXfs count=\"3\">" +
                "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
                "<xf numFmtId=\"49\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyNumberFormat=\"1\"/>" +
                "<xf numFmtId=\"49\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/>" +
                "</cellXfs>" +
                "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>" +
                "</styleSheet>";

            using (var ms = new MemoryStream())
            {
                using (var zip = new ZipArchive(ms, ZipArchiveMode.Create, true))
                {
                    AddEntry(zip, "[Content_Types].xml", contentTypes);
                    AddEntry(zip, "_rels/.rels", rootRels);
                    AddEntry(zip, "xl/workbook.xml", workbook);
                    AddEntry(zip, "xl/_rels/workbook.xml.rels", workbookRels);
                    AddEntry(zip, "xl/styles.xml", styles);
                    AddEntry(zip, "xl/worksheets/sheet1.xml", sheet.ToString());
                }
                return ms.ToArray();
            }
        }

        private static void AppendRow(StringBuilder sb, int rowNo, string[] values, int style)
        {
            sb.Append("<row r=\"" + rowNo + "\">");
            for (int i = 0; i < values.Length; i++)
            {
                sb.Append("<c r=\"" + ColumnName(i) + rowNo + "\" t=\"inlineStr\" s=\"" + style + "\"><is><t xml:space=\"preserve\">");
                sb.Append(SecurityElement.Escape(values[i] ?? ""));
                sb.Append("</t></is></c>");
            }
            sb.Append("</row>");
        }

        private static string ColumnName(int index)
        {
            var name = "";
            index++;
            while (index > 0)
            {
                int m = (index - 1) % 26;
                name = (char)('A' + m) + name;
                index = (index - 1) / 26;
            }
            return name;
        }

        private static void AddEntry(ZipArchive zip, string path, string content)
        {
            var entry = zip.CreateEntry(path, CompressionLevel.Optimal);
            using (var s = entry.Open())
            {
                var bytes = new UTF8Encoding(false).GetBytes(content);
                s.Write(bytes, 0, bytes.Length);
            }
        }
    }
}
