using System;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using Honda.Models;

namespace Honda.Controllers
{
    /// <summary>
    /// Master Data: Role, Organization, Operation, Department, Location Code, Zone, Region, Area.
    /// Admin only. Add / Edit / Activate / Deactivate / Bulk upload (preview, then confirm).
    /// </summary>
    [HandleError()]
    public class MasterController : Controller
    {
        private const string UploadSessionKey = "MasterUploadBatch";
        private static readonly TimeSpan UploadLifetime = TimeSpan.FromMinutes(30);
        private readonly MasterService _service = new MasterService();
        private readonly MasterRepository _repo = new MasterRepository();

        // ---------------------------------------------------------------- security

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var session = filterContext.HttpContext.Session;
            bool loggedIn = session != null && session["Uid"] != null && session["Type"] != null;
            bool isAdmin = loggedIn && string.Equals(Convert.ToString(session["Type"]).Trim(), "admin", StringComparison.OrdinalIgnoreCase);

            if (!isAdmin)
            {
                string message = loggedIn
                    ? "You do not have permission to manage master data."
                    : "Your session has expired. Please log in again.";
                if (filterContext.HttpContext.Request.IsAjaxRequest())
                {
                    filterContext.HttpContext.Response.StatusCode = loggedIn ? 403 : 401;
                    filterContext.HttpContext.Response.TrySkipIisCustomErrors = true;
                    filterContext.Result = Json(new { ok = false, message = message, sessionExpired = !loggedIn }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    filterContext.Result = new RedirectResult("~/Login/Login");
                }
                return;
            }
            base.OnActionExecuting(filterContext);
        }

        protected override void OnException(ExceptionContext filterContext)
        {
            WriteLog("MasterController error: " + filterContext.Exception);
            if (filterContext.HttpContext.Request.IsAjaxRequest())
            {
                bool tokenProblem = filterContext.Exception is HttpAntiForgeryException;
                filterContext.ExceptionHandled = true;
                filterContext.HttpContext.Response.StatusCode = tokenProblem ? 400 : 500;
                filterContext.HttpContext.Response.TrySkipIisCustomErrors = true;
                filterContext.Result = Json(new
                {
                    ok = false,
                    message = tokenProblem
                        ? "This page has expired. Please refresh the page (F5) and try again."
                        : "Something went wrong while processing your request. Please try again. If it keeps happening, contact the administrator."
                }, JsonRequestBehavior.AllowGet);
                return;
            }
            base.OnException(filterContext);
        }

        private string CurrentUser
        {
            get { return Convert.ToString(Session["Uid"]); }
        }

        // ---------------------------------------------------------------- page

        public ActionResult Index(string master)
        {
            var def = MasterRegistry.Find(master) ?? MasterRegistry.All[0];
            ViewBag.SelectedMaster = def.Key;
            ViewBag.MastersJson = new JavaScriptSerializer().Serialize(MasterRegistry.All.Select(d => new
            {
                key = d.Key,
                label = d.Label,
                minLength = d.MinLength,
                maxLength = d.MaxLength,
                pattern = d.Pattern,
                patternMessage = d.PatternMessage,
                example = d.Example,
                isMultiValue = d.IsMultiValue
            }));
            return View(MasterRegistry.All);
        }

        // ---------------------------------------------------------------- list

        [HttpGet]
        public ActionResult List(string master)
        {
            var def = MasterRegistry.Find(master);
            if (def == null) return UnknownMaster();

            var rows = _repo.List(def).Select(r => new
            {
                id = r.Id,
                name = r.Name,
                isActive = r.IsActive,
                createdBy = r.CreatedBy,
                createdDate = Fmt(r.CreatedDate),
                updatedBy = r.UpdatedBy,
                updatedDate = Fmt(r.UpdatedDate)
            }).ToList();
            return BigJson(new { ok = true, rows = rows });
        }

        // ---------------------------------------------------------------- add / edit

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Save(string master, int? id, string name, string isActive)
        {
            var def = MasterRegistry.Find(master);
            if (def == null) return UnknownMaster();

            bool active = !string.Equals(isActive, "false", StringComparison.OrdinalIgnoreCase) && isActive != "0";
            var result = _service.Save(def, id ?? 0, name, active, CurrentUser);
            WriteLogIfOk(result, "Save " + def.Key + " id=" + (id ?? 0) + " name=" + MasterValidator.Normalize(name));
            return Json(new { ok = result.Ok, message = result.Message, fieldError = result.FieldError });
        }

        // ---------------------------------------------------------------- activate / deactivate

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SetStatus(string master, int id, bool isActive)
        {
            var def = MasterRegistry.Find(master);
            if (def == null) return UnknownMaster();

            var result = _service.SetStatus(def, id, isActive, CurrentUser);
            WriteLogIfOk(result, "SetStatus " + def.Key + " id=" + id + " active=" + isActive);
            return Json(new { ok = result.Ok, message = result.Message });
        }

        // ---------------------------------------------------------------- template / export

        /// <summary>
        /// Upload file layout. sample=true fills it with example rows (one in lower case to show
        /// it is converted, one Inactive) so users can see exactly what a valid file looks like.
        /// </summary>
        [HttpGet]
        public ActionResult Template(string master, string format, bool sample = false)
        {
            var def = MasterRegistry.Find(master);
            if (def == null) return HttpNotFound();

            var headers = new[] { def.Label, "Status" };
            var rows = sample && def.SampleRows != null ? def.SampleRows : new string[0][];
            var fileBase = def.Label.Replace(" ", "_") + (sample ? "_Sample" : "_Template");
            if (string.Equals(format, "csv", StringComparison.OrdinalIgnoreCase))
                return File(MasterFile.WriteCsv(headers, rows), "text/csv", fileBase + ".csv");
            return File(MasterFile.WriteXlsx(def.Label, headers, rows, new[] { 45, 14 }), XlsxMime, fileBase + ".xlsx");
        }

        /// <summary>All values of the master (Active and Inactive) as .xlsx (default) or .csv.</summary>
        [HttpGet]
        public ActionResult Export(string master, string format)
        {
            var def = MasterRegistry.Find(master);
            if (def == null) return HttpNotFound();

            var rows = _repo.List(def).Select(r => new[]
            {
                r.Name, r.IsActive ? "Active" : "Inactive", r.CreatedBy, Fmt(r.CreatedDate), r.UpdatedBy, Fmt(r.UpdatedDate)
            }).ToList();
            var headers = new[] { def.Label, "Status", "Created By", "Created On", "Updated By", "Updated On" };
            var fileBase = def.Label.Replace(" ", "_") + "_Master_" + DateTime.Now.ToString("yyyyMMdd_HHmm");
            if (string.Equals(format, "csv", StringComparison.OrdinalIgnoreCase))
                return File(MasterFile.WriteCsv(headers, rows), "text/csv", fileBase + ".csv");
            return File(MasterFile.WriteXlsx(def.Label, headers, rows, new[] { 45, 12, 16, 18, 16, 18 }), XlsxMime, fileBase + ".xlsx");
        }

        private const string XlsxMime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

        // ---------------------------------------------------------------- bulk upload

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UploadPreview(string master, HttpPostedFileBase file)
        {
            var def = MasterRegistry.Find(master);
            if (def == null) return UnknownMaster();

            if (file == null || file.ContentLength == 0 || string.IsNullOrWhiteSpace(file.FileName))
                return Json(new { ok = false, message = "Please choose a .xlsx or .csv file to upload." });

            var fileName = Path.GetFileName(file.FileName);
            UploadBatch batch;
            try
            {
                var fileRows = MasterFile.Read(file.InputStream, fileName);
                batch = _service.Preview(def, fileRows, fileName);
            }
            catch (MasterFileException ex)
            {
                return Json(new { ok = false, message = ex.Message });
            }

            Session[UploadSessionKey] = batch;
            int valid = batch.Rows.Count(r => r.IsValid);
            return BigJson(new
            {
                ok = true,
                token = batch.Token,
                fileName = batch.FileName,
                total = batch.Rows.Count,
                valid = valid,
                invalid = batch.Rows.Count - valid,
                rows = batch.Rows.Select(r => new
                {
                    rowNo = r.RowNo,
                    input = r.Input,
                    value = r.Value,
                    status = r.IsActive ? "Active" : "Inactive",
                    statusInput = r.StatusInput,
                    isValid = r.IsValid,
                    errors = r.Errors
                })
            });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UploadConfirm(string master, string token)
        {
            var def = MasterRegistry.Find(master);
            if (def == null) return UnknownMaster();

            var batch = Session[UploadSessionKey] as UploadBatch;
            if (batch == null || batch.Token != token || DateTime.UtcNow - batch.CreatedUtc > UploadLifetime)
                return Json(new { ok = false, message = "This preview has expired or was replaced by another upload. Please upload the file again." });
            if (!string.Equals(batch.MasterKey, def.Key, StringComparison.OrdinalIgnoreCase))
                return Json(new { ok = false, message = "This file was previewed for a different master. Please upload it again on the " + def.Label + " tab." });

            var result = _service.Confirm(def, batch, CurrentUser);
            if (result.Ok) Session.Remove(UploadSessionKey);
            WriteLogIfOk(result, "BulkUpload " + def.Key + " file=" + batch.FileName + " : " + result.Message);
            return Json(new { ok = result.Ok, message = result.Message });
        }

        // ---------------------------------------------------------------- helpers

        private ActionResult UnknownMaster()
        {
            return Json(new { ok = false, message = "Unknown master type. Please refresh the page." }, JsonRequestBehavior.AllowGet);
        }

        private JsonResult BigJson(object data)
        {
            return new JsonResult { Data = data, JsonRequestBehavior = JsonRequestBehavior.AllowGet, MaxJsonLength = int.MaxValue };
        }

        private static string Fmt(DateTime? d)
        {
            return d.HasValue ? d.Value.ToString("dd-MM-yyyy HH:mm") : "";
        }

        private void WriteLogIfOk(MasterResult result, string action)
        {
            if (result.Ok) WriteLog("[Master] user=" + CurrentUser + " " + action);
        }

        private static void WriteLog(string message)
        {
            try
            {
                string text = string.Format("Time: {0}{1}-----------------------------------------------------------{1}Message: {2}{1}-----------------------------------------------------------{1}",
                    DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"), Environment.NewLine, message);
                System.IO.File.AppendAllText(AppDomain.CurrentDomain.BaseDirectory + @"\Log.txt", text + Environment.NewLine);
            }
            catch
            {
                // logging must never break the request
            }
        }
    }
}
