using System;
using System.Collections.Generic;
using System.Linq;
using MySql.Data.MySqlClient;

namespace Honda.Models
{
    public class MasterResult
    {
        public bool Ok { get; set; }
        public string Message { get; set; }
        public string FieldError { get; set; }   // error shown under the Name box
    }

    public class UploadRow
    {
        public int RowNo { get; set; }
        public string Input { get; set; }        // what the file contained
        public string Value { get; set; }        // what will be saved (UPPERCASE)
        public string StatusInput { get; set; }
        public bool IsActive { get; set; }
        public bool IsValid { get; set; }
        public List<string> Errors { get; set; }
    }

    public class UploadBatch
    {
        public string Token { get; set; }
        public string MasterKey { get; set; }
        public string FileName { get; set; }
        public DateTime CreatedUtc { get; set; }
        public List<UploadRow> Rows { get; set; }
    }

    /// <summary>Business rules for the master pages. Controllers stay thin.</summary>
    public class MasterService
    {
        private readonly MasterRepository _repo = new MasterRepository();

        // --------------------------------------------------------------- add / edit

        public MasterResult Save(MasterDefinition def, int id, string rawName, bool isActive, string user)
        {
            var name = MasterValidator.Normalize(rawName);
            var errors = MasterValidator.Validate(def, name);
            if (errors.Count > 0)
                return new MasterResult { Ok = false, FieldError = string.Join(" ", errors) };

            var duplicate = _repo.FindByName(def, name, id);
            if (duplicate != null)
            {
                var msg = "'" + name + "' already exists in the " + def.Label + " master";
                msg += duplicate.IsActive ? "." : " but is Inactive. Activate the existing entry instead of adding it again.";
                return new MasterResult { Ok = false, FieldError = msg };
            }

            if (id <= 0)
            {
                try
                {
                    _repo.Insert(def, name, isActive, user);
                }
                catch (MySqlException ex) when (ex.Number == 1062)
                {
                    return new MasterResult { Ok = false, FieldError = "'" + name + "' already exists in the " + def.Label + " master." };
                }
                return new MasterResult { Ok = true, Message = def.Label + " '" + name + "' added successfully" + (isActive ? "." : " as Inactive.") };
            }

            var existing = _repo.GetById(def, id);
            if (existing == null)
                return new MasterResult { Ok = false, Message = "This " + def.Label + " no longer exists. Please refresh the page." };

            bool renamed = !string.Equals(existing.Name, name, StringComparison.OrdinalIgnoreCase);
            int usage = 0;
            if (renamed || (existing.IsActive && !isActive))
                usage = _repo.UsageCount(def, existing.Name);

            if (renamed && usage > 0)
            {
                return new MasterResult
                {
                    Ok = false,
                    FieldError = "Cannot rename '" + existing.Name + "' to '" + name + "' because it is assigned to " + usage +
                                 " user(s). Deactivate '" + existing.Name + "' and add '" + name + "' as a new " + def.Label + " instead."
                };
            }

            try
            {
                _repo.Update(def, id, name, isActive, user);
            }
            catch (MySqlException ex) when (ex.Number == 1062)
            {
                return new MasterResult { Ok = false, FieldError = "'" + name + "' already exists in the " + def.Label + " master." };
            }

            var message = def.Label + " '" + name + "' updated successfully.";
            if (existing.IsActive && !isActive)
                message += DeactivationNote(usage);
            return new MasterResult { Ok = true, Message = message };
        }

        // --------------------------------------------------------------- activate / deactivate

        public MasterResult SetStatus(MasterDefinition def, int id, bool isActive, string user)
        {
            var existing = _repo.GetById(def, id);
            if (existing == null)
                return new MasterResult { Ok = false, Message = "This " + def.Label + " no longer exists. Please refresh the page." };
            if (existing.IsActive == isActive)
                return new MasterResult { Ok = true, Message = def.Label + " '" + existing.Name + "' is already " + (isActive ? "Active." : "Inactive.") };

            _repo.SetActive(def, id, isActive, user);
            if (isActive)
                return new MasterResult { Ok = true, Message = def.Label + " '" + existing.Name + "' activated. It is available in the user forms again." };

            int usage = _repo.UsageCount(def, existing.Name);
            return new MasterResult { Ok = true, Message = def.Label + " '" + existing.Name + "' deactivated." + DeactivationNote(usage) };
        }

        private static string DeactivationNote(int usage)
        {
            var note = " It will no longer be offered in the Add / Edit User forms.";
            if (usage > 0)
                note += " " + usage + " user(s) already have this value and keep it.";
            return note;
        }

        // --------------------------------------------------------------- bulk upload

        /// <summary>Reads the file and validates every row. Nothing is saved here.</summary>
        public UploadBatch Preview(MasterDefinition def, List<FileRow> fileRows, string fileName)
        {
            // first non-empty row is the header
            var nonEmpty = fileRows.Where(r => r.Cells.Any(c => !string.IsNullOrWhiteSpace(c))).ToList();
            if (nonEmpty.Count == 0)
                throw new MasterFileException("The file has no data. Use the template: first row = headings, values from row 2.");

            var header = nonEmpty[0];
            int nameCol = -1, statusCol = -1;
            for (int i = 0; i < header.Cells.Length; i++)
            {
                var h = HeaderKey(header.Cells[i]);
                if (nameCol < 0 && (h == HeaderKey(def.Label) || h == "NAME" || h == "VALUE")) nameCol = i;
                else if (statusCol < 0 && (h == "STATUS" || h == "ISACTIVE" || h == "ACTIVE")) statusCol = i;
            }
            if (nameCol < 0)
            {
                throw new MasterFileException("Row " + header.RowNo + " must be the heading row with the columns '" + def.Label +
                    "' and 'Status'. Found: " + string.Join(", ", header.Cells.Where(c => !string.IsNullOrWhiteSpace(c)).Select(c => "'" + c.Trim() + "'")) +
                    ". Please download the " + def.Label + " template and use it.");
            }

            var dataRows = nonEmpty.Skip(1).ToList();
            if (dataRows.Count == 0)
                throw new MasterFileException("The file contains only the heading row. Add the " + def.Label + " values from row 2 onwards.");
            if (dataRows.Count > MasterFile.MaxDataRows)
                throw new MasterFileException("The file has " + dataRows.Count + " data rows. A maximum of " + MasterFile.MaxDataRows + " rows can be uploaded at a time - please split the file.");

            var existing = new MasterRepository().AllNames(def);
            var firstSeen = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            var result = new List<UploadRow>();

            foreach (var fr in dataRows)
            {
                var input = nameCol < fr.Cells.Length ? fr.Cells[nameCol] : "";
                var statusInput = statusCol >= 0 && statusCol < fr.Cells.Length ? fr.Cells[statusCol] : "";
                var value = MasterValidator.Normalize(input);
                var errors = MasterValidator.Validate(def, value);

                var status = MasterValidator.ParseStatus(statusInput);
                if (status == null)
                    errors.Add("Status '" + statusInput.Trim() + "' is not valid. Use Active or Inactive (leave blank for Active).");

                if (errors.Count == 0)
                {
                    int firstRow;
                    if (firstSeen.TryGetValue(value, out firstRow))
                        errors.Add("Duplicate: '" + value + "' already appears in row " + firstRow + " of this file.");
                    else
                    {
                        firstSeen[value] = fr.RowNo;
                        if (existing.Contains(value))
                            errors.Add("'" + value + "' already exists in the " + def.Label + " master.");
                    }
                }

                result.Add(new UploadRow
                {
                    RowNo = fr.RowNo,
                    Input = input,
                    Value = value,
                    StatusInput = statusInput,
                    IsActive = status ?? true,
                    IsValid = errors.Count == 0,
                    Errors = errors
                });
            }

            return new UploadBatch
            {
                Token = Guid.NewGuid().ToString("N"),
                MasterKey = def.Key,
                FileName = fileName,
                CreatedUtc = DateTime.UtcNow,
                Rows = result
            };
        }

        /// <summary>Saves the valid rows of a previewed batch.</summary>
        public MasterResult Confirm(MasterDefinition def, UploadBatch batch, string user)
        {
            var valid = batch.Rows.Where(r => r.IsValid).ToList();
            if (valid.Count == 0)
                return new MasterResult { Ok = false, Message = "There are no valid rows to save. Correct the errors in the file and upload it again." };

            int inserted;
            var skipped = _repo.BulkInsert(def, valid.Select(r => new KeyValuePair<string, bool>(r.Value, r.IsActive)), user, out inserted);

            var msg = inserted + " " + def.Label + " value(s) saved successfully.";
            int invalid = batch.Rows.Count - valid.Count;
            if (invalid > 0) msg += " " + invalid + " row(s) with errors were not saved.";
            if (skipped.Count > 0)
                msg += " " + skipped.Count + " value(s) were skipped because they were added by someone else in the meantime: " +
                       string.Join(", ", skipped.Take(10)) + (skipped.Count > 10 ? ", ..." : "") + ".";
            return new MasterResult { Ok = true, Message = msg };
        }

        private static string HeaderKey(string s)
        {
            return new string((s ?? "").ToUpperInvariant().Where(char.IsLetterOrDigit).ToArray());
        }
    }
}
