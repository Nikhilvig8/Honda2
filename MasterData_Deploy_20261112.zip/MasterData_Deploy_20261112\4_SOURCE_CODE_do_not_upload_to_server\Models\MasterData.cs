using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text.RegularExpressions;
using MySql.Data.MySqlClient;

namespace Honda.Models
{
    /// <summary>
    /// Describes one master list (Role, Organization, ...). This is the ONLY place
    /// table / column names come from, so no user input is ever put into SQL text.
    /// </summary>
    public class MasterDefinition
    {
        public string Key { get; set; }            // used in URLs: role, organization, ...
        public string Label { get; set; }          // shown to the user: "Location Code"
        public string Table { get; set; }          // mst_* table
        public string UserColumn { get; set; }     // matching column in tblusers
        public bool IsMultiValue { get; set; }     // tblusers stores a comma separated list
        public int MinLength { get; set; }
        public int MaxLength { get; set; }
        public string Pattern { get; set; }        // must work in both .NET and JavaScript
        public string PatternMessage { get; set; }
        public string Example { get; set; }
        public string[][] SampleRows { get; set; } // example data for the downloadable sample file
    }

    public static class MasterRegistry
    {
        private const string CodePattern = "^[A-Z][A-Z0-9_]*$";

        public static readonly List<MasterDefinition> All = new List<MasterDefinition>
        {
            new MasterDefinition {
                Key = "role", Label = "Role", Table = "mst_role", UserColumn = "Role", IsMultiValue = false,
                MinLength = 2, MaxLength = 50, Pattern = "^[A-Z][A-Z0-9_ ]*$",
                PatternMessage = "Role can contain only letters, numbers, underscore (_) and spaces, and must start with a letter.",
                Example = "HONDA_SALES_HO",
                SampleRows = new[] { new[] { "HONDA_TRAINING_HO", "Active" }, new[] { "dealer_trainee", "Active" }, new[] { "HONDA_OLD_ROLE", "Inactive" } } },
            new MasterDefinition {
                Key = "organization", Label = "Organization", Table = "mst_organization", UserColumn = "Organization", IsMultiValue = false,
                MinLength = 2, MaxLength = 150, Pattern = "^[A-Z0-9][A-Z0-9 &().,/'-]*$",
                PatternMessage = "Organization can contain only letters, numbers, spaces and the symbols & ( ) . , / ' - and must start with a letter or number.",
                Example = "HONDA CARS INDIA LTD",
                SampleRows = new[] { new[] { "SAMPLE HONDA PVT. LTD.", "Active" }, new[] { "abc motors (p) ltd", "Active" }, new[] { "OLD DEALER & SONS", "Inactive" } } },
            new MasterDefinition {
                Key = "operation", Label = "Operation", Table = "mst_operation", UserColumn = "Operation", IsMultiValue = true,
                MinLength = 2, MaxLength = 30, Pattern = CodePattern,
                PatternMessage = "Operation can contain only letters, numbers and underscore (_) - no spaces or commas - and must start with a letter.",
                Example = "SALES",
                SampleRows = new[] { new[] { "SALES_SUPPORT", "Active" }, new[] { "accessories", "Active" }, new[] { "OLD_OPERATION", "Inactive" } } },
            new MasterDefinition {
                Key = "department", Label = "Department", Table = "mst_department", UserColumn = "Department", IsMultiValue = true,
                MinLength = 2, MaxLength = 60, Pattern = "^[A-Z][A-Z0-9 &/_-]*$",
                PatternMessage = "Department can contain only letters, numbers, spaces and the symbols & / _ - (no commas), and must start with a letter.",
                Example = "SERVICE PLANNING",
                SampleRows = new[] { new[] { "CUSTOMER CARE", "Active" }, new[] { "parts & accessories", "Active" }, new[] { "OLD DEPARTMENT", "Inactive" } } },
            new MasterDefinition {
                Key = "location", Label = "Location Code", Table = "mst_location_code", UserColumn = "Location_Code", IsMultiValue = false,
                MinLength = 2, MaxLength = 15, Pattern = "^[A-Z0-9]+$",
                PatternMessage = "Location Code can contain only letters and numbers - no spaces or symbols.",
                Example = "DD035",
                SampleRows = new[] { new[] { "DD999", "Active" }, new[] { "dd999a", "Active" }, new[] { "DD998", "Inactive" } } },
            new MasterDefinition {
                Key = "zone", Label = "Zone", Table = "mst_zone", UserColumn = "Zone", IsMultiValue = true,
                MinLength = 2, MaxLength = 30, Pattern = CodePattern,
                PatternMessage = "Zone can contain only letters, numbers and underscore (_) - no spaces or commas - and must start with a letter.",
                Example = "NORTH",
                SampleRows = new[] { new[] { "CENTRAL", "Active" }, new[] { "north_east", "Active" }, new[] { "OLD_ZONE", "Inactive" } } },
            new MasterDefinition {
                Key = "region", Label = "Region", Table = "mst_region", UserColumn = "Region", IsMultiValue = true,
                MinLength = 2, MaxLength = 30, Pattern = CodePattern,
                PatternMessage = "Region can contain only letters, numbers and underscore (_) - no spaces or commas - and must start with a letter.",
                Example = "NORTH1",
                SampleRows = new[] { new[] { "CENTRAL1", "Active" }, new[] { "northeast1", "Active" }, new[] { "OLD_REGION", "Inactive" } } },
            new MasterDefinition {
                Key = "area", Label = "Area", Table = "mst_area", UserColumn = "Area", IsMultiValue = true,
                MinLength = 2, MaxLength = 30, Pattern = CodePattern,
                PatternMessage = "Area can contain only letters, numbers and underscore (_) - no spaces or commas - and must start with a letter.",
                Example = "ALL_AREAS",
                SampleRows = new[] { new[] { "AREA_01", "Active" }, new[] { "area_02", "Active" }, new[] { "OLD_AREA", "Inactive" } } },
        };

        public static MasterDefinition Find(string key)
        {
            if (string.IsNullOrWhiteSpace(key)) return null;
            return All.FirstOrDefault(d => string.Equals(d.Key, key.Trim(), StringComparison.OrdinalIgnoreCase));
        }
    }

    /// <summary>Same rules for Add, Edit and Bulk Upload.</summary>
    public static class MasterValidator
    {
        private static readonly HashSet<string> Placeholders =
            new HashSet<string>(new[] { "NULL", "N/A", "NA", "NONE", "NIL", "-", ".", "--", "#N/A" });

        private static readonly Regex Whitespace = new Regex(@"[\s ]+", RegexOptions.Compiled);

        /// <summary>Line breaks / tabs / repeated spaces -> one space, trim, UPPERCASE.</summary>
        public static string Normalize(string raw)
        {
            if (raw == null) return string.Empty;
            return Whitespace.Replace(raw, " ").Trim().ToUpperInvariant();
        }

        /// <summary>Returns every problem with the (already normalised) value; empty list = valid.</summary>
        public static List<string> Validate(MasterDefinition def, string value)
        {
            var errors = new List<string>();
            if (string.IsNullOrEmpty(value))
            {
                errors.Add(def.Label + " is required.");
                return errors;
            }
            if (Placeholders.Contains(value))
            {
                errors.Add("'" + value + "' is not a valid " + def.Label + ". Enter the actual value.");
                return errors;
            }
            if (value.Length < def.MinLength)
                errors.Add(def.Label + " must be at least " + def.MinLength + " characters (you entered " + value.Length + ").");
            if (value.Length > def.MaxLength)
                errors.Add(def.Label + " cannot be longer than " + def.MaxLength + " characters (you entered " + value.Length + ").");
            if (!Regex.IsMatch(value, def.Pattern))
                errors.Add(def.PatternMessage);
            return errors;
        }

        /// <summary>Status text from a file. Blank = Active.</summary>
        public static bool? ParseStatus(string raw)
        {
            var s = Normalize(raw);
            switch (s)
            {
                case "": case "ACTIVE": case "Y": case "YES": case "1": case "TRUE":
                    return true;
                case "INACTIVE": case "N": case "NO": case "0": case "FALSE":
                    return false;
                default:
                    return null;
            }
        }
    }

    public class MasterItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }

    /// <summary>Data access for the mst_* tables. Parameterised SQL only.</summary>
    public class MasterRepository
    {
        private readonly string _conn = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;

        public List<MasterItem> List(MasterDefinition def)
        {
            var sql = "SELECT Id, Name, IsActive, CreatedBy, CreatedDate, UpdatedBy, UpdatedDate FROM `" + def.Table + "` ORDER BY Name";
            var list = new List<MasterItem>();
            using (var cn = new MySqlConnection(_conn))
            using (var cmd = new MySqlCommand(sql, cn))
            {
                cn.Open();
                using (var rd = cmd.ExecuteReader())
                {
                    while (rd.Read()) list.Add(Map(rd));
                }
            }
            return list;
        }

        public MasterItem GetById(MasterDefinition def, int id)
        {
            var sql = "SELECT Id, Name, IsActive, CreatedBy, CreatedDate, UpdatedBy, UpdatedDate FROM `" + def.Table + "` WHERE Id = @id";
            using (var cn = new MySqlConnection(_conn))
            using (var cmd = new MySqlCommand(sql, cn))
            {
                cmd.Parameters.AddWithValue("@id", id);
                cn.Open();
                using (var rd = cmd.ExecuteReader())
                {
                    return rd.Read() ? Map(rd) : null;
                }
            }
        }

        /// <summary>Existing row with the same name (case-insensitive), optionally ignoring one Id.</summary>
        public MasterItem FindByName(MasterDefinition def, string name, int excludeId)
        {
            var sql = "SELECT Id, Name, IsActive, CreatedBy, CreatedDate, UpdatedBy, UpdatedDate FROM `" + def.Table +
                      "` WHERE Name = @name AND Id <> @id LIMIT 1";   // column collation is case-insensitive
            using (var cn = new MySqlConnection(_conn))
            using (var cmd = new MySqlCommand(sql, cn))
            {
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@id", excludeId);
                cn.Open();
                using (var rd = cmd.ExecuteReader())
                {
                    return rd.Read() ? Map(rd) : null;
                }
            }
        }

        public HashSet<string> AllNames(MasterDefinition def)
        {
            var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            using (var cn = new MySqlConnection(_conn))
            using (var cmd = new MySqlCommand("SELECT Name FROM `" + def.Table + "`", cn))
            {
                cn.Open();
                using (var rd = cmd.ExecuteReader())
                {
                    while (rd.Read()) set.Add(rd.GetString(0));
                }
            }
            return set;
        }

        /// <summary>How many users in tblusers currently have this value.</summary>
        public int UsageCount(MasterDefinition def, string name)
        {
            string sql;
            if (def.IsMultiValue)
            {
                // tblusers stores e.g. "SALES,SERVICE" - match one item of the list
                sql = "SELECT COUNT(*) FROM tblusers WHERE FIND_IN_SET(@name, UPPER(TRIM(REGEXP_REPLACE(IFNULL(`" +
                      def.UserColumn + @"`, ''), '\\s*,\\s*', ',')))) > 0";
            }
            else
            {
                sql = "SELECT COUNT(*) FROM tblusers WHERE UPPER(TRIM(`" + def.UserColumn + "`)) = @name";
            }
            using (var cn = new MySqlConnection(_conn))
            using (var cmd = new MySqlCommand(sql, cn))
            {
                cmd.Parameters.AddWithValue("@name", name.ToUpperInvariant());
                cn.Open();
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        public int Insert(MasterDefinition def, string name, bool isActive, string user)
        {
            var sql = "INSERT INTO `" + def.Table + "` (Name, IsActive, CreatedBy, CreatedDate) VALUES (@name, @active, @user, NOW()); SELECT LAST_INSERT_ID();";
            using (var cn = new MySqlConnection(_conn))
            using (var cmd = new MySqlCommand(sql, cn))
            {
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@active", isActive ? 1 : 0);
                cmd.Parameters.AddWithValue("@user", user);
                cn.Open();
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        public void Update(MasterDefinition def, int id, string name, bool isActive, string user)
        {
            var sql = "UPDATE `" + def.Table + "` SET Name = @name, IsActive = @active, UpdatedBy = @user, UpdatedDate = NOW() WHERE Id = @id";
            using (var cn = new MySqlConnection(_conn))
            using (var cmd = new MySqlCommand(sql, cn))
            {
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@active", isActive ? 1 : 0);
                cmd.Parameters.AddWithValue("@user", user);
                cmd.Parameters.AddWithValue("@id", id);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void SetActive(MasterDefinition def, int id, bool isActive, string user)
        {
            var sql = "UPDATE `" + def.Table + "` SET IsActive = @active, UpdatedBy = @user, UpdatedDate = NOW() WHERE Id = @id";
            using (var cn = new MySqlConnection(_conn))
            using (var cmd = new MySqlCommand(sql, cn))
            {
                cmd.Parameters.AddWithValue("@active", isActive ? 1 : 0);
                cmd.Parameters.AddWithValue("@user", user);
                cmd.Parameters.AddWithValue("@id", id);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Inserts all rows in one transaction. Rows whose name already exists
        /// (e.g. added by someone else since the preview) are skipped and returned.
        /// </summary>
        public List<string> BulkInsert(MasterDefinition def, IEnumerable<KeyValuePair<string, bool>> rows, string user, out int inserted)
        {
            inserted = 0;
            var skipped = new List<string>();
            var sql = "INSERT IGNORE INTO `" + def.Table + "` (Name, IsActive, CreatedBy, CreatedDate) VALUES (@name, @active, @user, NOW())";
            using (var cn = new MySqlConnection(_conn))
            {
                cn.Open();
                using (var tx = cn.BeginTransaction())
                {
                    try
                    {
                        using (var cmd = new MySqlCommand(sql, cn, tx))
                        {
                            var pName = cmd.Parameters.Add("@name", MySqlDbType.VarChar);
                            var pActive = cmd.Parameters.Add("@active", MySqlDbType.Int32);
                            cmd.Parameters.AddWithValue("@user", user);
                            foreach (var row in rows)
                            {
                                pName.Value = row.Key;
                                pActive.Value = row.Value ? 1 : 0;
                                if (cmd.ExecuteNonQuery() == 1) inserted++;
                                else skipped.Add(row.Key);
                            }
                        }
                        tx.Commit();
                    }
                    catch
                    {
                        tx.Rollback();
                        inserted = 0;
                        throw;
                    }
                }
            }
            return skipped;
        }

        private static MasterItem Map(MySqlDataReader rd)
        {
            return new MasterItem
            {
                Id = Convert.ToInt32(rd["Id"]),
                Name = Convert.ToString(rd["Name"]),
                IsActive = Convert.ToInt32(rd["IsActive"]) == 1,
                CreatedBy = rd["CreatedBy"] == DBNull.Value ? "" : Convert.ToString(rd["CreatedBy"]),
                CreatedDate = rd["CreatedDate"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(rd["CreatedDate"]),
                UpdatedBy = rd["UpdatedBy"] == DBNull.Value ? "" : Convert.ToString(rd["UpdatedBy"]),
                UpdatedDate = rd["UpdatedDate"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(rd["UpdatedDate"]),
            };
        }
    }
}
