-- =====================================================================
-- Honda SMAART - Master Data module
-- Script 02 : OPTIONAL - re-sync from tblmaster + data check reports
--
-- NOT needed for the first install: script 01 already creates the tables
-- WITH the master data. Run this only if
--   (a) tblmaster on the server has values that were not in tblmaster.xlsx
--       (it adds only the missing ones - existing rows are untouched), or
--   (b) you want the VERIFY reports at the bottom (VERIFY 3 lists values
--       users already have in tblusers that are not in the masters).
--
-- * tblmaster is only READ - it is not changed or dropped (kept as backup).
-- * Each value is cleaned the same way the application cleans input:
--     - line breaks / tabs / non-breaking spaces / repeated spaces -> one space
--     - leading / trailing spaces removed
--     - converted to UPPERCASE
-- * Skipped: NULL, empty, and placeholder text ('NULL', 'N/A', 'NA', '-', 'NONE').
-- * Duplicates (incl. case-only duplicates like 'Apex Honda' / 'APEX HONDA')
--   collapse into one row.
-- * Safe to re-run: values that already exist are not inserted again.
-- =====================================================================

USE honda;

-- ---------- Role ----------
INSERT IGNORE INTO mst_role (Name, IsActive, CreatedBy)
SELECT DISTINCT v, 1, 'MIGRATION' FROM (
    SELECT UPPER(TRIM(REGEXP_REPLACE(`Role`, '[\\s\\x{00A0}]+', ' '))) AS v FROM tblmaster
) s
WHERE v IS NOT NULL AND v <> '' AND v NOT IN ('NULL','N/A','NA','-','NONE')
  AND CHAR_LENGTH(v) <= 50;

-- ---------- Organization ----------
INSERT IGNORE INTO mst_organization (Name, IsActive, CreatedBy)
SELECT DISTINCT v, 1, 'MIGRATION' FROM (
    SELECT UPPER(TRIM(REGEXP_REPLACE(`Organization`, '[\\s\\x{00A0}]+', ' '))) AS v FROM tblmaster
) s
WHERE v IS NOT NULL AND v <> '' AND v NOT IN ('NULL','N/A','NA','-','NONE')
  AND CHAR_LENGTH(v) <= 150;

-- ---------- Operation ----------
INSERT IGNORE INTO mst_operation (Name, IsActive, CreatedBy)
SELECT DISTINCT v, 1, 'MIGRATION' FROM (
    SELECT UPPER(TRIM(REGEXP_REPLACE(`Operation`, '[\\s\\x{00A0}]+', ' '))) AS v FROM tblmaster
) s
WHERE v IS NOT NULL AND v <> '' AND v NOT IN ('NULL','N/A','NA','-','NONE')
  AND CHAR_LENGTH(v) <= 30;

-- ---------- Department ----------
INSERT IGNORE INTO mst_department (Name, IsActive, CreatedBy)
SELECT DISTINCT v, 1, 'MIGRATION' FROM (
    SELECT UPPER(TRIM(REGEXP_REPLACE(`Department`, '[\\s\\x{00A0}]+', ' '))) AS v FROM tblmaster
) s
WHERE v IS NOT NULL AND v <> '' AND v NOT IN ('NULL','N/A','NA','-','NONE')
  AND CHAR_LENGTH(v) <= 60;

-- ---------- Location Code ----------
INSERT IGNORE INTO mst_location_code (Name, IsActive, CreatedBy)
SELECT DISTINCT v, 1, 'MIGRATION' FROM (
    SELECT UPPER(TRIM(REGEXP_REPLACE(`Location Code`, '[\\s\\x{00A0}]+', ' '))) AS v FROM tblmaster
) s
WHERE v IS NOT NULL AND v <> '' AND v NOT IN ('NULL','N/A','NA','-','NONE')
  AND CHAR_LENGTH(v) <= 15;

-- ---------- Zone ----------
INSERT IGNORE INTO mst_zone (Name, IsActive, CreatedBy)
SELECT DISTINCT v, 1, 'MIGRATION' FROM (
    SELECT UPPER(TRIM(REGEXP_REPLACE(`Zone`, '[\\s\\x{00A0}]+', ' '))) AS v FROM tblmaster
) s
WHERE v IS NOT NULL AND v <> '' AND v NOT IN ('NULL','N/A','NA','-','NONE')
  AND CHAR_LENGTH(v) <= 30;

-- ---------- Region ----------
INSERT IGNORE INTO mst_region (Name, IsActive, CreatedBy)
SELECT DISTINCT v, 1, 'MIGRATION' FROM (
    SELECT UPPER(TRIM(REGEXP_REPLACE(`Region`, '[\\s\\x{00A0}]+', ' '))) AS v FROM tblmaster
) s
WHERE v IS NOT NULL AND v <> '' AND v NOT IN ('NULL','N/A','NA','-','NONE')
  AND CHAR_LENGTH(v) <= 30;

-- ---------- Area ----------
INSERT IGNORE INTO mst_area (Name, IsActive, CreatedBy)
SELECT DISTINCT v, 1, 'MIGRATION' FROM (
    SELECT UPPER(TRIM(REGEXP_REPLACE(`Area`, '[\\s\\x{00A0}]+', ' '))) AS v FROM tblmaster
) s
WHERE v IS NOT NULL AND v <> '' AND v NOT IN ('NULL','N/A','NA','-','NONE')
  AND CHAR_LENGTH(v) <= 30;

-- =====================================================================
-- VERIFY 1 : row counts.  Expected from tblmaster.csv analysis (12-Nov-2026):
--   Role 19 | Organization 368 | Operation 5 | Department 16
--   Location Code 584 | Zone 5 | Region 16 | Area 1
-- =====================================================================
SELECT 'Role' AS Master, COUNT(*) AS Total FROM mst_role
UNION ALL SELECT 'Organization',  COUNT(*) FROM mst_organization
UNION ALL SELECT 'Operation',     COUNT(*) FROM mst_operation
UNION ALL SELECT 'Department',    COUNT(*) FROM mst_department
UNION ALL SELECT 'Location Code', COUNT(*) FROM mst_location_code
UNION ALL SELECT 'Zone',          COUNT(*) FROM mst_zone
UNION ALL SELECT 'Region',        COUNT(*) FROM mst_region
UNION ALL SELECT 'Area',          COUNT(*) FROM mst_area;

-- =====================================================================
-- VERIFY 2 : values that were TOO LONG and therefore NOT migrated
--            (expected: no rows). Fix them manually if any appear.
-- =====================================================================
SELECT 'Role' AS Master, `Role` AS Value FROM tblmaster WHERE CHAR_LENGTH(TRIM(`Role`)) > 50
UNION ALL SELECT 'Organization',  `Organization`  FROM tblmaster WHERE CHAR_LENGTH(TRIM(`Organization`)) > 150
UNION ALL SELECT 'Operation',     `Operation`     FROM tblmaster WHERE CHAR_LENGTH(TRIM(`Operation`)) > 30
UNION ALL SELECT 'Department',    `Department`    FROM tblmaster WHERE CHAR_LENGTH(TRIM(`Department`)) > 60
UNION ALL SELECT 'Location Code', `Location Code` FROM tblmaster WHERE CHAR_LENGTH(TRIM(`Location Code`)) > 15
UNION ALL SELECT 'Zone',          `Zone`          FROM tblmaster WHERE CHAR_LENGTH(TRIM(`Zone`)) > 30
UNION ALL SELECT 'Region',        `Region`        FROM tblmaster WHERE CHAR_LENGTH(TRIM(`Region`)) > 30
UNION ALL SELECT 'Area',          `Area`          FROM tblmaster WHERE CHAR_LENGTH(TRIM(`Area`)) > 30;

-- =====================================================================
-- VERIFY 3 : values already assigned to users (tblusers) that are NOT in
--            the new masters. These users keep their value; the edit form
--            shows it as "(inactive)". Review and add to the master if needed.
--            (Single-value columns only; multi-value columns are comma lists.)
-- =====================================================================
SELECT 'Role' AS Master, UPPER(TRIM(u.Role)) AS Value, COUNT(*) AS Users
FROM tblusers u
WHERE IFNULL(TRIM(u.Role),'') <> ''
  AND UPPER(TRIM(u.Role)) NOT IN (SELECT Name FROM mst_role)
GROUP BY UPPER(TRIM(u.Role))
UNION ALL
SELECT 'Organization', UPPER(TRIM(u.Organization)), COUNT(*)
FROM tblusers u
WHERE IFNULL(TRIM(u.Organization),'') <> ''
  AND UPPER(TRIM(REGEXP_REPLACE(u.Organization, '[\\s\\x{00A0}]+', ' '))) NOT IN (SELECT Name FROM mst_organization)
GROUP BY UPPER(TRIM(u.Organization))
UNION ALL
SELECT 'Location Code', UPPER(TRIM(u.Location_Code)), COUNT(*)
FROM tblusers u
WHERE IFNULL(TRIM(u.Location_Code),'') <> ''
  AND UPPER(TRIM(u.Location_Code)) NOT IN (SELECT Name FROM mst_location_code)
GROUP BY UPPER(TRIM(u.Location_Code))
ORDER BY 1, 2;
