-- =====================================================================
-- Honda SMAART - Master Data module
-- Script 03 : Point the user-form dropdowns at the new master tables
-- Run AFTER 02_migrate_tblmaster_to_masters.sql
--
-- !! BEFORE RUNNING: back up the current procedure !!
--    Run:  SHOW CREATE PROCEDURE honda.getAllDropdown;
--    Right-click the "Create Procedure" cell -> Open Value in Editor -> copy
--    the full text into a file (e.g. getAllDropdown_BACKUP.sql).
--    04_rollback.sql has an approximate copy, but your saved original is safer.
--
-- The result shape is IDENTICAL to the old procedure, so these pages keep
-- working without change: Home/Index, Home/IndexUser, Home/UpdateProfile.
--   Result set 1 : one row with RoleCount, OrganizationCount, OperationCount,
--                  DepartmentCount, Location_CodeCount, ZoneCount,
--                  RegionCount, AreaCount
--   Result set 2 : rows with columns Role, Organization, Operation,
--                  Department, Location_Code, Zone, Region, Area
--                  (row k holds the k-th value of every list; shorter lists
--                   are NULL-padded, exactly like tblmaster)
--
-- Only ACTIVE values are returned. Values starting with 'ALL' (ALL_ZONES,
-- ALL_REGIONS, ALL_AREAS, ALL) are listed first, the rest alphabetically.
-- =====================================================================

USE honda;

DROP PROCEDURE IF EXISTS getAllDropdown;

DELIMITER $$

CREATE PROCEDURE getAllDropdown()
BEGIN
    -- Result set 1 : counts
    SELECT
        (SELECT COUNT(*) FROM mst_role          WHERE IsActive = 1) AS RoleCount,
        (SELECT COUNT(*) FROM mst_organization  WHERE IsActive = 1) AS OrganizationCount,
        (SELECT COUNT(*) FROM mst_operation     WHERE IsActive = 1) AS OperationCount,
        (SELECT COUNT(*) FROM mst_department    WHERE IsActive = 1) AS DepartmentCount,
        (SELECT COUNT(*) FROM mst_location_code WHERE IsActive = 1) AS Location_CodeCount,
        (SELECT COUNT(*) FROM mst_zone          WHERE IsActive = 1) AS ZoneCount,
        (SELECT COUNT(*) FROM mst_region        WHERE IsActive = 1) AS RegionCount,
        (SELECT COUNT(*) FROM mst_area          WHERE IsActive = 1) AS AreaCount;

    -- Result set 2 : the lists, side by side
    WITH
      r  AS (SELECT Name, ROW_NUMBER() OVER (ORDER BY (Name NOT LIKE 'ALL%'), Name) AS rn FROM mst_role          WHERE IsActive = 1),
      o  AS (SELECT Name, ROW_NUMBER() OVER (ORDER BY (Name NOT LIKE 'ALL%'), Name) AS rn FROM mst_organization  WHERE IsActive = 1),
      op AS (SELECT Name, ROW_NUMBER() OVER (ORDER BY (Name NOT LIKE 'ALL%'), Name) AS rn FROM mst_operation     WHERE IsActive = 1),
      d  AS (SELECT Name, ROW_NUMBER() OVER (ORDER BY (Name NOT LIKE 'ALL%'), Name) AS rn FROM mst_department    WHERE IsActive = 1),
      l  AS (SELECT Name, ROW_NUMBER() OVER (ORDER BY (Name NOT LIKE 'ALL%'), Name) AS rn FROM mst_location_code WHERE IsActive = 1),
      z  AS (SELECT Name, ROW_NUMBER() OVER (ORDER BY (Name NOT LIKE 'ALL%'), Name) AS rn FROM mst_zone          WHERE IsActive = 1),
      rg AS (SELECT Name, ROW_NUMBER() OVER (ORDER BY (Name NOT LIKE 'ALL%'), Name) AS rn FROM mst_region        WHERE IsActive = 1),
      a  AS (SELECT Name, ROW_NUMBER() OVER (ORDER BY (Name NOT LIKE 'ALL%'), Name) AS rn FROM mst_area          WHERE IsActive = 1),
      n  AS (SELECT rn FROM r  UNION SELECT rn FROM o  UNION SELECT rn FROM op UNION SELECT rn FROM d
             UNION SELECT rn FROM l UNION SELECT rn FROM z UNION SELECT rn FROM rg UNION SELECT rn FROM a)
    SELECT
        r.Name  AS Role,
        o.Name  AS Organization,
        op.Name AS Operation,
        d.Name  AS Department,
        l.Name  AS Location_Code,
        z.Name  AS Zone,
        rg.Name AS Region,
        a.Name  AS Area
    FROM n
    LEFT JOIN r  ON r.rn  = n.rn
    LEFT JOIN o  ON o.rn  = n.rn
    LEFT JOIN op ON op.rn = n.rn
    LEFT JOIN d  ON d.rn  = n.rn
    LEFT JOIN l  ON l.rn  = n.rn
    LEFT JOIN z  ON z.rn  = n.rn
    LEFT JOIN rg ON rg.rn = n.rn
    LEFT JOIN a  ON a.rn  = n.rn
    ORDER BY n.rn;
END$$

DELIMITER ;

-- Verify: should return 2 result sets (counts, then the lists)
CALL getAllDropdown();
