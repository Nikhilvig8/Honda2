HONDA SMAART - MASTER DATA MODULE - DEPLOYMENT PACKAGE (12-Nov-2026)
=====================================================================

FOLDERS IN THIS ZIP
-------------------
1_WEBSITE_FILES\        -> copy into the website folder on the UAT server (same paths)
2_DATABASE_SCRIPTS\     -> run in MySQL Workbench on UAT
3_SAMPLE_FILES\         -> sample upload files (with example data) for every master
4_SOURCE_CODE_do_not_upload_to_server\ -> C# source + project file, for the code repository only.
                           Do NOT copy this folder into the website.

DO NOT UPLOAD / OVERWRITE:  Web.config, packages\, obj\, any other DLL in bin\


STEP 0 - BACKUP (on the server, before anything else)
-----------------------------------------------------
  Copy these server files somewhere safe:
    bin\Honda.dll
    Views\Shared\_Layout.cshtml
    Views\Home\Index.cshtml
    Views\Home\IndexUser.cshtml
    Views\Home\UpdateProfile.cshtml
    Views\Home\iframeIndex.cshtml
  In MySQL Workbench run:  SHOW CREATE PROCEDURE honda.getAllDropdown;
    right-click the "Create Procedure" cell -> Open Value in Editor -> copy the
    FULL text into getAllDropdown_BACKUP.sql


STEP 1 - DATABASE (MySQL Workbench)
-----------------------------------
  Run ONE file:  2_DATABASE_SCRIPTS\MASTER_DATA_UAT_SINGLE_SCRIPT.sql
    File > Open SQL Script > Execute ALL (lightning icon / Ctrl+Shift+Enter)
  It FIRST backs up the old getAllDropdown into table mst_backup_procedures
  (and stops, changing nothing, if the backup cannot be saved), then
  creates the 8 master tables with data, replaces getAllDropdown,
  and shows verification results. Expected counts:
       Role 19 | Organization 368 | Operation 5 | Department 16
       Location Code 584 | Zone 5 | Region 16 | Area 1
  If the last check says "Unknown column", STOP and tell the developer.

  (The numbered scripts 01-04 are the same content split into parts;
   not needed if you run the single script. 04_rollback.sql = undo.)

STEP 2 - WEBSITE FILES
----------------------
  Copy from 1_WEBSITE_FILES\ into the website folder, keeping the paths:
    bin\Honda.dll                       (replaced)
    Views\Master\Index.cshtml           (NEW - create folder Views\Master)
    Views\Shared\_Layout.cshtml         (replaced)
    Views\Home\Index.cshtml             (replaced)
    Views\Home\IndexUser.cshtml         (replaced)
    Views\Home\UpdateProfile.cshtml     (replaced)
    Views\Home\iframeIndex.cshtml       (replaced)
  Note: replacing Honda.dll restarts the site - logged-in users are logged out.


STEP 3 - TEST ON UAT
--------------------
  Log in as admin -> User Management -> left menu "Master Data"
   [ ] Each of the 8 tabs lists values (counts as in Step 1)
   [ ] Add a value in lower case -> saved in UPPERCASE
   [ ] Add the same value again -> "already exists" message
   [ ] Edit a value used by users -> rename is blocked with a user count
   [ ] Deactivate / Activate a value -> message; deactivated value disappears
       from Add User dropdown
   [ ] Template / Sample download (xlsx + csv); Export (xlsx + csv)
   [ ] Bulk Upload the sample file -> preview (green/red) -> Save valid rows
   [ ] User Management -> Edit a user -> all dropdowns show the user's values
   [ ] Add User still works; Update Profile and normal (non-admin) user page open
   [ ] Admin still sees admin menu; dealer users still get their dashboard


ROLLBACK (if something is wrong)
--------------------------------
  Website : put back the backed-up files from Step 0.
  Database: restore from table mst_backup_procedures (see 04_rollback.sql).
            The mst_* tables can stay; they do not affect the old pages.

