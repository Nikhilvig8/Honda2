-- =====================================================================
-- Honda SMAART - Master Data module
-- Script 04 : ROLLBACK (only if something goes wrong)
--
-- Step 1 puts the user-form dropdowns back on tblmaster.
--   PREFERRED: the exact original, saved automatically by the UAT script:
--     SELECT FullCreateSql FROM mst_backup_procedures WHERE RoutineName = 'getAllDropdown'
--     right-click the cell, Open Value in Editor, copy it into a new query tab,
--     put DROP PROCEDURE IF EXISTS getAllDropdown above it, wrap the CREATE in
--     DELIMITER dollar-dollar ... dollar-dollar DELIMITER semicolon, and run.
--   FALLBACK : the procedure below. It is reconstructed from the visible part
--              of the original (counts + all tblmaster rows) and returns the
--              same result shape the pages expect.
--
-- Step 2 (optional, commented out) removes the master tables. Leave them in
-- place unless you are sure - they hold any values added through the new page.
-- =====================================================================

USE honda;

-- ---------- Step 1 : restore getAllDropdown on tblmaster ----------
DROP PROCEDURE IF EXISTS getAllDropdown;

DELIMITER $$

CREATE PROCEDURE getAllDropdown()
BEGIN
    SELECT COUNT(Role)         AS RoleCount,
           COUNT(Organization) AS OrganizationCount,
           COUNT(Operation)    AS OperationCount,
           COUNT(Department)   AS DepartmentCount,
           COUNT(*)            AS Location_CodeCount,
           COUNT(Zone)         AS ZoneCount,
           COUNT(Region)       AS RegionCount,
           COUNT(Area)         AS AreaCount
    FROM tblmaster;

    SELECT Role, Organization, Operation, Department,
           `Location Code` AS Location_Code, Zone, Region, Area
    FROM tblmaster;
END$$

DELIMITER ;

CALL getAllDropdown();

-- ---------- Step 2 : OPTIONAL - drop the master tables ----------
-- DROP TABLE IF EXISTS mst_role;
-- DROP TABLE IF EXISTS mst_organization;
-- DROP TABLE IF EXISTS mst_operation;
-- DROP TABLE IF EXISTS mst_department;
-- DROP TABLE IF EXISTS mst_location_code;
-- DROP TABLE IF EXISTS mst_zone;
-- DROP TABLE IF EXISTS mst_region;
-- DROP TABLE IF EXISTS mst_area;
